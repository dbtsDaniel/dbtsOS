# dbtsOS v9 – Deploy (Cloudflare Pages)

Detta är en statisk PWA (ingen build, ingen Node). Du kan ladda upp direkt.

## Cloudflare Pages (enklast)
1) Skapa nytt Pages-projekt → **Upload assets** (Direct Upload)
2) Ladda upp innehållet i zippen (rotmappen).
3) Klart. Ingen build-kommando, ingen output-folder.

## Lokal test (om du vill)
Service Worker funkar inte via `file://`. Kör en lokal server:

### Python
```bash
python -m http.server 8080
```
Öppna sedan http://localhost:8080

## Data & Sync (viktigt)
Allt du skriver sparas lokalt i din webbläsare (IndexedDB).
- Det betyder: **ingen automatisk synk** mellan mobil/dator utan backend.
- Lösningen i v9: **Settings → Backup (Export/Import)** för att flytta data mellan enheter.

## Bank
Första gången du öppnar appen importeras `data/seed_bank.json` automatiskt (om banken är tom).
Du kan också importera egen CSV/JSON i Bank/Settings.

## Tips
- På mobil: välj “Lägg till på hemskärmen” (PWA) för riktig app-känsla.
- Om något skulle strula: öppna DevTools → Console. Appen visar även en liten status i hörnet.
