/* dbtsOS v9 – single-file app logic (vanilla JS, offline-first) */
(() => {
  "use strict";

  // ---------- Tiny helpers ----------
  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const nowISO = () => new Date().toISOString();
  const uuid = () =>
    (crypto?.randomUUID?.() || "id_" + Math.random().toString(16).slice(2) + "_" + Date.now().toString(16));

  function debounce(fn, wait=160){
    let t=null;
    return (...args) => {
      clearTimeout(t);
      t=setTimeout(()=>fn(...args), wait);
    };
  }

  function escapeHtml(s){
    return (s ?? "").toString()
      .replaceAll("&","&amp;")
      .replaceAll("<","&lt;")
      .replaceAll(">","&gt;")
      .replaceAll('"',"&quot;")
      .replaceAll("'","&#039;");
  }

  function toast(title, msg){
    const host = $("#toastHost");
    if(!host) return;
    const div = document.createElement("div");
    div.className = "toast";
    div.innerHTML = `<div class="toast__title">${escapeHtml(title)}</div><div class="toast__msg">${escapeHtml(msg)}</div>`;
    host.appendChild(div);
    setTimeout(() => {
      div.style.opacity = "0";
      div.style.transform = "translateY(-6px)";
      setTimeout(() => div.remove(), 350);
    }, 3200);
  }

  function setDbStatus(s){
    const el = $("#dbStatus");
    if(el) el.textContent = s;
  }

  // ---------- Modal ----------
  const modal = $("#modal");
  const modalTitle = $("#modalTitle");
  const modalBody = $("#modalBody");
  const modalFoot = $("#modalFoot");
  const modalOk = $("#modalOk");

  function openModal({title, bodyHtml, okText="Spara", cancelText="Avbryt", onOk}){
    modalTitle.textContent = title;
    modalBody.innerHTML = bodyHtml;
    $("#modalOk").textContent = okText;
    $$("#modalFoot button[value='cancel']").forEach(b => b.textContent = cancelText);
    modalOk.onclick = (e) => {
      e.preventDefault();
      try { onOk?.(); modal.close(); } catch(err) {
        console.error(err);
        toast("Fel", err?.message || "Okänt fel");
      }
    };
    modal.showModal();
  }

  // ---------- IndexedDB wrapper ----------
  const DB_NAME = "dbtsOS";
  const DB_VERSION = 9;

  const STORES = {
    meta: "meta",
    worlds: "worlds",
    profiles: "profiles",
    albums: "albums",
    tracks: "tracks",
    bank: "bank",
    vault: "vault",
    snapshots: "snapshots"
  };

  let db = null;

  function idbReq(req){
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  function tx(store, mode="readonly"){
    const t = db.transaction(store, mode);
    return t.objectStore(store);
  }

  async function openDb(){
    if(db) return db;
    setDbStatus("DB: öppnar…");
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (ev) => {
      const d = req.result;

      const ensure = (name, opts, indexes=[]) => {
        if(!d.objectStoreNames.contains(name)){
          const s = d.createObjectStore(name, opts);
          indexes.forEach(ix => s.createIndex(ix.name, ix.keyPath, ix.options || {}));
        } else {
          // add missing indexes in upgrades
          const s = req.transaction.objectStore(name);
          indexes.forEach(ix => {
            if(!s.indexNames.contains(ix.name)){
              s.createIndex(ix.name, ix.keyPath, ix.options || {});
            }
          });
        }
      };

      ensure(STORES.meta, {keyPath: "key"});
      ensure(STORES.worlds, {keyPath: "id"}, [
        {name:"by_updated", keyPath:"updated_at"}
      ]);
      ensure(STORES.profiles, {keyPath: "id"}, [
        {name:"by_world", keyPath:"world_id"},
        {name:"by_updated", keyPath:"updated_at"}
      ]);
      ensure(STORES.albums, {keyPath: "id"}, [
        {name:"by_profile", keyPath:"profile_id"},
        {name:"by_updated", keyPath:"updated_at"}
      ]);
      ensure(STORES.tracks, {keyPath: "id"}, [
        {name:"by_album", keyPath:"album_id"},
        {name:"by_updated", keyPath:"updated_at"},
        {name:"by_status", keyPath:"status"},
        {name:"by_fav", keyPath:"favorite"}
      ]);
      ensure(STORES.bank, {keyPath: "id"}, [
        {name:"by_type", keyPath:"type"},
        {name:"by_impact", keyPath:"ratings.impact"} // not used but reserved
      ]);
      ensure(STORES.vault, {keyPath: "id"}, [
        {name:"by_updated", keyPath:"updated_at"}
      ]);
      ensure(STORES.snapshots, {keyPath: "id"}, [
        {name:"by_track", keyPath:"track_id"},
        {name:"by_created", keyPath:"created_at"}
      ]);
    };
    db = await idbReq(req);
    setDbStatus("DB: ok");
    return db;
  }

  async function kvGet(key, fallback=null){
    const r = tx(STORES.meta).get(key);
    const res = await idbReq(r).catch(()=>null);
    return res?.value ?? fallback;
  }
  async function kvSet(key, value){
    const r = tx(STORES.meta, "readwrite").put({key, value});
    await idbReq(r);
  }

  async function getAll(store){
    const r = tx(store).getAll();
    return await idbReq(r);
  }

  async function getById(store, id){
    if(!id) return null;
    const r = tx(store).get(id);
    return await idbReq(r);
  }

  async function put(store, obj){
    obj.updated_at = nowISO();
    const r = tx(store,"readwrite").put(obj);
    return await idbReq(r);
  }

  async function del(store, id){
    const r = tx(store,"readwrite").delete(id);
    return await idbReq(r);
  }

  async function clearStore(store){
    const r = tx(store,"readwrite").clear();
    return await idbReq(r);
  }

  // ---------- App State ----------
  const state = {
    route: "home",
    world_id: null,
    profile_id: null,
    album_id: null,
    track_id: null,
    bank_loaded: false,
    bank_cache: null, // in-memory list for search
    bank_last_loaded_at: 0,
    bank_query: "",
    bank_theme: "Alla",
    wizard_mode: "Draft",
    wizard_theme: "",
    wizard_style: "mörk, cinematic, svensk, 12/8 (trioler), glitch, glass",
    wizard_exclude: "klichéer, självhjälpsfraser, engelska oneliners, generisk motivational tone",
    reduced_motion: false
  };

  function routeFromHash(){
    const h = location.hash.replace(/^#\/?/, "");
    if(!h) return "home";
    const p = h.split("/")[0];
    return ["home","editor","wizard","bank","vault","settings"].includes(p) ? p : "home";
  }

  function setRoute(route){
    state.route = route;
    location.hash = `#/${route}`;
    syncNav(route);
    render();
  }

  function syncNav(route){
    $$(".nav__item, .bottomnav__item").forEach(btn => {
      btn.classList.toggle("is-active", btn.dataset.route === route);
    });
  }

  function setBreadcrumb({viewLabel=""}){
    const parts = [];
    if(state.world_id) parts.push("värld");
    if(state.profile_id) parts.push("profil");
    if(state.album_id) parts.push("album");
    if(state.track_id) parts.push("spår");
    const base = parts.length ? "dbtsOS/" + parts.join("/") : "dbtsOS";
    $("#breadcrumb").textContent = base + (viewLabel ? " / " + viewLabel : "");
  }

  // ---------- Context & inheritance ----------
  async function ensureDefaults(){
    // create a default world/profile/album if none exists
    const worlds = await getAll(STORES.worlds);
    if(worlds.length === 0){
      const w = {id: uuid(), name:"dbts-världen", description:"Din kreativa världskarta.", dna:"", anti:"", cover:null, updated_at: nowISO()};
      await put(STORES.worlds, w);
      await kvSet("world_id", w.id);
      toast("Init", "Skapade standardvärld.");
    }
    const world_id = await kvGet("world_id", null);
    if(world_id) state.world_id = world_id;

    const profiles = (await getAll(STORES.profiles)).filter(p => p.world_id === state.world_id);
    if(profiles.length === 0){
      const p = {id: uuid(), world_id: state.world_id, name:"TredAI", description:"Profil/artist i dbts.", dna:"", anti:"", cover:null, updated_at: nowISO()};
      await put(STORES.profiles, p);
      await kvSet("profile_id", p.id);
      toast("Init", "Skapade profil: TredAI.");
    }
    const profile_id = await kvGet("profile_id", null);
    if(profile_id) state.profile_id = profile_id;

    const albums = (await getAll(STORES.albums)).filter(a => a.profile_id === state.profile_id);
    if(albums.length === 0){
      const a = {id: uuid(), profile_id: state.profile_id, name:"För Sverige i Tiden", description:"Albumyta. Lägg spår, versioner, remixar.", dna:"", anti:"", cover:null, updated_at: nowISO()};
      await put(STORES.albums, a);
      await kvSet("album_id", a.id);
      toast("Init", "Skapade album: För Sverige i Tiden.");
    }
    const album_id = await kvGet("album_id", null);
    if(album_id) state.album_id = album_id;

    const track_id = await kvGet("track_id", null);
    if(track_id) state.track_id = track_id;
  }

  async function getContext(){
    const world = await getById(STORES.worlds, state.world_id);
    const profile = await getById(STORES.profiles, state.profile_id);
    const album = await getById(STORES.albums, state.album_id);
    const track = await getById(STORES.tracks, state.track_id);
    const dnaParts = [world?.dna, profile?.dna, album?.dna, track?.dna].filter(Boolean);
    const antiParts = [world?.anti, profile?.anti, album?.anti, track?.anti].filter(Boolean);
    const pathParts = [
      world?.name ? `dbts/${world.name}` : "dbts",
      profile?.name ? profile.name : "",
      album?.name ? album.name : "",
      track?.title ? track.title : ""
    ].filter(Boolean);

    return {
      world, profile, album, track,
      dna: dnaParts.join("\n\n---\n\n"),
      anti: antiParts.join("\n\n---\n\n"),
      path: pathParts.join(" / ")
    };
  }

  // ---------- Seed bank ----------
  async function bankCount(){
    const r = tx(STORES.bank).count();
    return await idbReq(r);
  }

  async function importSeedBankIfNeeded(){
    const count = await bankCount();
    if(count > 0){
      state.bank_loaded = true;
      return;
    }
    toast("Bank", "Tom bank. Importerar seed-bank…");
    setDbStatus("DB: importerar bank…");

    // fetch seed json
    let seed = null;
    try{
      const res = await fetch("data/seed_bank.json", {cache:"no-cache"});
      seed = await res.json();
    }catch(err){
      console.error(err);
      toast("Bank", "Kunde inte hämta seed_bank.json. Testa att deploya på Cloudflare Pages (https) eller importera manuellt i Settings.");
      setDbStatus("DB: ok (bank tom)");
      return;
    }

    // chunk insert (keeps UI responsive)
    const chunkSize = 400;
    for(let i=0; i<seed.length; i+=chunkSize){
      const chunk = seed.slice(i, i+chunkSize);
      const t = db.transaction(STORES.bank, "readwrite");
      const store = t.objectStore(STORES.bank);
      await new Promise((resolve, reject) => {
        chunk.forEach(obj => store.put(obj));
        t.oncomplete = resolve;
        t.onerror = () => reject(t.error);
        t.onabort = () => reject(t.error);
      });
      if(i % (chunkSize*3) === 0){
        toast("Bank", `Import: ${clamp(Math.round((i/seed.length)*100),0,100)}%`);
        await sleep(10);
      }
    }

    state.bank_loaded = true;
    setDbStatus("DB: ok");
    toast("Bank", `Import klar: ${seed.length} rader ✅`);
  }

  async function loadBankCache(force=false){
    const t = Date.now();
    if(state.bank_cache && !force && (t - state.bank_last_loaded_at) < 3000) return state.bank_cache;
    const all = await getAll(STORES.bank);
    state.bank_cache = all;
    state.bank_last_loaded_at = t;
    return all;
  }

  // ---------- UI building blocks ----------
  function card({title, sub="", actionsHtml="", bodyHtml=""}){
    return `
      <div class="card">
        <div class="card__head">
          <div>
            <div class="card__title">${escapeHtml(title)}</div>
            ${sub ? `<div class="card__sub">${escapeHtml(sub)}</div>` : ""}
          </div>
          ${actionsHtml ? `<div class="card__actions">${actionsHtml}</div>` : ""}
        </div>
        ${bodyHtml}
      </div>
    `;
  }

  function contextSelectorHtml(ctx){
    const worldName = ctx.world?.name ?? "—";
    const profileName = ctx.profile?.name ?? "—";
    const albumName = ctx.album?.name ?? "—";
    const trackName = ctx.track?.title ?? "—";

    return `
      <div class="row">
        <div class="field">
          <div class="label">Värld</div>
          <select class="select" id="selWorld"></select>
        </div>
        <div class="field">
          <div class="label">Profil</div>
          <select class="select" id="selProfile"></select>
        </div>
        <div class="field">
          <div class="label">Album</div>
          <select class="select" id="selAlbum"></select>
        </div>
        <div class="field">
          <div class="label">Spår</div>
          <select class="select" id="selTrack"></select>
        </div>
      </div>

      <div class="row" style="margin-top:10px;">
        <button class="btn btn--ghost" id="btnEditWorld">✦ Värld</button>
        <button class="btn btn--ghost" id="btnEditProfile">✦ Profil</button>
        <button class="btn btn--ghost" id="btnEditAlbum">✦ Album</button>
        <button class="btn" id="btnEditTrack">✦ Spår</button>
      </div>

      <div style="margin-top:10px;">
        <span class="chip chip--accent">Path</span>
        <span class="chip">${escapeHtml(ctx.path || "dbtsOS")}</span>
      </div>
    `;
  }

  async function mountContextSelector(){
    const ctx = await getContext();

    const worlds = await getAll(STORES.worlds);
    const profiles = (await getAll(STORES.profiles)).filter(p => p.world_id === state.world_id);
    const albums = (await getAll(STORES.albums)).filter(a => a.profile_id === state.profile_id);
    const tracks = (await getAll(STORES.tracks)).filter(t => t.album_id === state.album_id).sort((a,b) => (b.updated_at||"").localeCompare(a.updated_at||""));

    const selWorld = $("#selWorld");
    const selProfile = $("#selProfile");
    const selAlbum = $("#selAlbum");
    const selTrack = $("#selTrack");

    function fillSelect(sel, items, getLabel, currentId, placeholder="(välj)"){
      sel.innerHTML = "";
      const opt0 = document.createElement("option");
      opt0.value = "";
      opt0.textContent = placeholder;
      sel.appendChild(opt0);
      items.forEach(it => {
        const o=document.createElement("option");
        o.value = it.id;
        o.textContent = getLabel(it);
        if(it.id === currentId) o.selected = true;
        sel.appendChild(o);
      });
    }

    fillSelect(selWorld, worlds, w=>w.name, state.world_id, "(välj värld)");
    fillSelect(selProfile, profiles, p=>p.name, state.profile_id, "(välj profil)");
    fillSelect(selAlbum, albums, a=>a.name, state.album_id, "(välj album)");
    fillSelect(selTrack, tracks, t=>t.title || "(untitled)", state.track_id, "(välj spår)");

    selWorld.onchange = async () => {
      state.world_id = selWorld.value || null;
      await kvSet("world_id", state.world_id);
      // reset lower levels
      state.profile_id = null; state.album_id=null; state.track_id=null;
      await kvSet("profile_id", null); await kvSet("album_id", null); await kvSet("track_id", null);
      await ensureDefaults();
      render();
    };
    selProfile.onchange = async () => {
      state.profile_id = selProfile.value || null;
      await kvSet("profile_id", state.profile_id);
      state.album_id=null; state.track_id=null;
      await kvSet("album_id", null); await kvSet("track_id", null);
      await ensureDefaults();
      render();
    };
    selAlbum.onchange = async () => {
      state.album_id = selAlbum.value || null;
      await kvSet("album_id", state.album_id);
      state.track_id=null;
      await kvSet("track_id", null);
      render();
    };
    selTrack.onchange = async () => {
      state.track_id = selTrack.value || null;
      await kvSet("track_id", state.track_id);
      render();
    };

    $("#btnEditWorld").onclick = () => openRulesEditor("world");
    $("#btnEditProfile").onclick = () => openRulesEditor("profile");
    $("#btnEditAlbum").onclick = () => openRulesEditor("album");
    $("#btnEditTrack").onclick = () => openRulesEditor("track");
  }

  // ---------- Rules editor (DNA / Anti) ----------
  async function openRulesEditor(level){
    const ctx = await getContext();
    const obj = ctx[level];
    if(!obj){
      toast("Saknas", `Ingen ${level} vald.`);
      return;
    }

    const titleMap = {world:"Värld", profile:"Profil", album:"Album", track:"Spår"};
    const title = `${titleMap[level]}: ${obj.name || obj.title || "(namnlös)"}`;

    openModal({
      title,
      okText: "Spara",
      bodyHtml: `
        <div class="field">
          <div class="label">Namn</div>
          <input class="input" id="ruleName" value="${escapeHtml(obj.name || obj.title || "")}" />
        </div>
        <div class="field">
          <div class="label">Beskrivning</div>
          <input class="input" id="ruleDesc" value="${escapeHtml(obj.description || "")}" />
        </div>
        <div class="field">
          <div class="label">DNA (regler / stil / ramar)</div>
          <textarea class="textarea" id="ruleDNA" placeholder="Ex: Språk svenska. 12/8 trioler. Kall men fysisk. Inga klichéer.">${escapeHtml(obj.dna || "")}</textarea>
        </div>
        <div class="field">
          <div class="label">ANTI-bibel (förbud / undvik)</div>
          <textarea class="textarea" id="ruleANTI" placeholder="Ex: inga självhjälpsfraser, inga anglicismer, inga generiska rim.">${escapeHtml(obj.anti || "")}</textarea>
        </div>
        <div class="field">
          <div class="label">Cover (valfri bild)</div>
          <input class="input" type="file" accept="image/*" id="ruleCover" />
          <div class="label" style="margin-top:6px;color:var(--muted2)">Bild sparas lokalt i din browser (IndexedDB).</div>
        </div>
      `,
      onOk: async () => {
        const name = $("#ruleName").value.trim();
        const desc = $("#ruleDesc").value.trim();
        const dna = $("#ruleDNA").value.trim();
        const anti = $("#ruleANTI").value.trim();
        const coverInput = $("#ruleCover");

        let cover = obj.cover || null;
        if(coverInput?.files?.[0]){
          cover = await fileToDataUrl(coverInput.files[0]);
        }

        if(level === "track"){
          obj.title = name || obj.title || "Untitled";
        } else {
          obj.name = name || obj.name || "Untitled";
        }
        obj.description = desc;
        obj.dna = dna;
        obj.anti = anti;
        obj.cover = cover;

        await put(STORES[level+"s"] ?? STORES[level], obj).catch(async () => {
          // mapping fix
          const store = level==="world" ? STORES.worlds : level==="profile" ? STORES.profiles : level==="album" ? STORES.albums : STORES.tracks;
          await put(store, obj);
        });

        toast("Sparat", `${titleMap[level]} uppdaterad.`);
        render();
      }
    });
  }

  function fileToDataUrl(file){
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  // ---------- Track creation ----------
  async function createTrackQuick(){
    const id = uuid();
    const t = {
      id,
      album_id: state.album_id,
      title: "Nytt spår",
      status: "continue", // default
      favorite: false,
      dna: "",
      anti: "",
      lyrics: "",
      links: {suno:"", spotify:"", youtube:""},
      updated_at: nowISO()
    };
    await put(STORES.tracks, t);
    state.track_id = id;
    await kvSet("track_id", id);
    toast("Spår", "Skapade nytt spår.");
    setRoute("editor");
  }

  // ---------- Views ----------
  async function renderHome(){
    const ctx = await getContext();
    setBreadcrumb({viewLabel:"Hem"});
    const tracks = (await getAll(STORES.tracks)).filter(t => t.album_id === state.album_id)
      .sort((a,b)=> (b.updated_at||"").localeCompare(a.updated_at||""));

    const fav = tracks.filter(t => t.favorite).slice(0,10);
    const latest = tracks.slice(0,10);
    const cont = tracks.filter(t => (t.status||"")==="continue").slice(0,10);
    const v1 = tracks.filter(t => (t.status||"")==="v1").slice(0,5);
    const v2 = tracks.filter(t => (t.status||"")==="v2").slice(0,5);
    const fin = tracks.filter(t => (t.status||"")==="final").slice(0,5);
    const rem = tracks.filter(t => (t.status||"")==="remix").slice(0,5);

    const bankCnt = await bankCount();

    const kpiHtml = `
      <div class="kpi">
        <div class="kpi__item">Bank: ${bankCnt} rader</div>
        <div class="kpi__item">Spår: ${tracks.length}</div>
        <div class="kpi__item">Aktivt: ${escapeHtml(ctx.track?.title || "—")}</div>
      </div>
    `;

    const lists = (title, items, badge) => `
      <div class="card" style="grid-column: span 6;">
        <div class="card__head">
          <div>
            <div class="card__title">${escapeHtml(title)}</div>
            <div class="card__sub">${items.length ? "Klicka för att öppna." : "Tomt än – skapa spår."}</div>
          </div>
        </div>
        <div class="list">
          ${items.map(t => `
            <div class="item" data-open-track="${t.id}">
              <div class="item__main">
                <div class="item__title">${escapeHtml(t.title || "(untitled)")}</div>
                <div class="item__meta">${escapeHtml(t.status || "—")} • ${new Date(t.updated_at||Date.now()).toLocaleString()}</div>
              </div>
              <div class="item__actions">
                ${badge ? `<span class="badge ${badge}">${escapeHtml(t.status||"")}</span>` : ""}
                ${t.favorite ? `<span class="badge badge--fav">★</span>` : ""}
                <button class="iconBtn" data-open-track="${t.id}">Öppna</button>
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `;

    const view = $("#view");
    view.innerHTML = `
      <div class="grid">
        ${card({
          title:"Kontrollrum",
          sub:"Välj var du befinner dig i dbts-världen. DNA/ANTI ärver nedåt till Wizard/Suno-export.",
          actionsHtml:`<button class="btn btn--ghost" id="btnSeed">Importera seed-bank</button>`,
          bodyHtml: `<div style="margin-top:12px;">${contextSelectorHtml(ctx)}</div><hr class="sep"/>${kpiHtml}`
        })}

        ${lists("Top 10 (favoriter)", fav, "badge--fav")}
        ${lists("Senaste 10", latest, "")}
        ${lists("Fortsätt (10)", cont, "badge--continue")}
        ${lists("V1 (5)", v1, "")}
        ${lists("V2 (5)", v2, "")}
        ${lists("Final (5)", fin, "")}
        ${lists("Remix (5)", rem, "")}

        ${card({
          title:"Snabbstart: skriv → wizard → Suno",
          sub:"Minimal friktion. Du ska känna dig som en del av processen, inte som en admin.",
          bodyHtml: `
            <div class="row" style="margin-top:12px;">
              <button class="btn" id="btnGoEditor">✍️ Skriv</button>
              <button class="btn btn--ghost" id="btnGoWizard">🧙 Wizard</button>
              <button class="btn btn--ghost" id="btnGoBank">🏦 Bank</button>
              <button class="btn btn--ghost" id="btnGoVault">🗃️ Vault</button>
            </div>
          `
        })}
      </div>
    `;

    await mountContextSelector();

    $("#btnGoEditor").onclick = () => setRoute("editor");
    $("#btnGoWizard").onclick = () => setRoute("wizard");
    $("#btnGoBank").onclick = () => setRoute("bank");
    $("#btnGoVault").onclick = () => setRoute("vault");

    $$("#view [data-open-track]").forEach(el => {
      el.onclick = async () => {
        state.track_id = el.dataset.openTrack;
        await kvSet("track_id", state.track_id);
        setRoute("editor");
      };
    });

    $("#btnSeed").onclick = async () => {
      await importSeedBankIfNeeded();
      render();
    };
  }

  function statusOptions(current){
    const statuses = ["continue","v1","v2","final","remix","idea"];
    return statuses.map(s => `<option value="${s}" ${s===current ? "selected":""}>${s}</option>`).join("");
  }

  async function renderEditor(){
    const ctx = await getContext();
    setBreadcrumb({viewLabel:"Skriv"});
    const view = $("#view");

    const track = ctx.track;
    if(!track){
      view.innerHTML = `
        <div class="grid">
          ${card({
            title:"Ingen spår vald",
            sub:"Skapa ett spår och börja skriva. Allt autosparas.",
            actionsHtml:`<button class="btn" id="btnCreateTrack">＋ Skapa spår</button>`,
            bodyHtml:`<div style="margin-top:12px;">${contextSelectorHtml(ctx)}</div>`
          })}
        </div>
      `;
      await mountContextSelector();
      $("#btnCreateTrack").onclick = createTrackQuick;
      return;
    }

    const snaps = (await getAll(STORES.snapshots))
      .filter(s => s.track_id === track.id)
      .sort((a,b) => (b.created_at||"").localeCompare(a.created_at||""))
      .slice(0, 12);

    const bank = await loadBankCache();
    const rec = recommendBankLines(bank, track, ctx);

    view.innerHTML = `
      <div class="grid">
        ${card({
          title:`Editor: ${track.title || "(untitled)"}`,
          sub:"Autosave i IndexedDB. Spara snapshots när du vill. Dra in bankrader med +.",
          actionsHtml: `
            <button class="btn btn--ghost" id="btnSnap">💾 Snapshot</button>
            <button class="btn btn--ghost" id="btnExportMd">⇱ Export .md</button>
            <button class="btn" id="btnFav">${track.favorite ? "★ Favorit" : "☆ Markera favorit"}</button>
          `,
          bodyHtml: `
            <div style="margin-top:12px;">${contextSelectorHtml(ctx)}</div>
            <hr class="sep"/>
            <div class="row">
              <div class="field">
                <div class="label">Titel</div>
                <input class="input" id="edTitle" value="${escapeHtml(track.title || "")}" />
              </div>
              <div class="field">
                <div class="label">Status</div>
                <select class="select" id="edStatus">${statusOptions(track.status||"continue")}</select>
              </div>
              <div class="field">
                <div class="label">Suno-länk (valfritt)</div>
                <input class="input" id="edSuno" placeholder="https://..." value="${escapeHtml(track.links?.suno || "")}" />
              </div>
            </div>

            <div class="split" style="margin-top:12px;">
              <div>
                <div class="field">
                  <div class="label">Lyrics</div>
                  <textarea class="textarea" id="edLyrics" placeholder="[Intro]\n...\n\n[Vers 1]\n...\n">${escapeHtml(track.lyrics || "")}</textarea>
                </div>
                <div class="row" style="margin-top:10px;">
                  <button class="btn btn--ghost" id="btnInsertHook">＋ [HOOK]</button>
                  <button class="btn btn--ghost" id="btnInsertVerse">＋ [VERS]</button>
                  <button class="btn btn--ghost" id="btnInsertBridge">＋ [BRYGGA]</button>
                  <button class="btn" id="btnToWizard">⚡ Skicka till Wizard</button>
                </div>

                <hr class="sep"/>
                <div class="card__title">Snapshots</div>
                <div class="list">
                  ${snaps.length ? snaps.map(s => `
                    <div class="item">
                      <div class="item__main">
                        <div class="item__title">${escapeHtml(s.label || "Snapshot")}</div>
                        <div class="item__meta">${new Date(s.created_at).toLocaleString()}</div>
                      </div>
                      <div class="item__actions">
                        <button class="iconBtn" data-restore="${s.id}">Återställ</button>
                        <button class="iconBtn" data-del-snap="${s.id}">Radera</button>
                      </div>
                    </div>
                  `).join("") : `<div class="item"><div class="item__main"><div class="item__meta">Inga snapshots ännu.</div></div></div>`}
                </div>
              </div>

              <div>
                ${card({
                  title:"Bank-rekommendationer",
                  sub:"Snabbplock baserat på tema/nyckelord + din context (DNA/ANTI).",
                  actionsHtml:`<button class="btn btn--ghost" id="btnOpenBank">Öppna Bank</button>`,
                  bodyHtml: `
                    <div class="field" style="margin-top:12px;">
                      <div class="label">Sök snabbt (bank)</div>
                      <input class="input" id="recSearch" placeholder="t.ex. system, natt, ADHD…" />
                    </div>
                    <div class="list" id="recList" style="margin-top:10px;">
                      ${rec.map(r => bankItemHtml(r, true)).join("")}
                    </div>
                  `
                })}
              </div>
            </div>
          `
        })}
      </div>
    `;

    await mountContextSelector();

    const saveDebounced = debounce(async () => {
      const t = await getById(STORES.tracks, track.id);
      if(!t) return;
      t.title = $("#edTitle").value.trim() || t.title;
      t.status = $("#edStatus").value;
      t.lyrics = $("#edLyrics").value;
      t.links = t.links || {};
      t.links.suno = $("#edSuno").value.trim();
      await put(STORES.tracks, t);
    }, 250);

    $("#edTitle").addEventListener("input", saveDebounced);
    $("#edStatus").addEventListener("change", saveDebounced);
    $("#edLyrics").addEventListener("input", saveDebounced);
    $("#edSuno").addEventListener("input", saveDebounced);

    $("#btnFav").onclick = async () => {
      const t = await getById(STORES.tracks, track.id);
      t.favorite = !t.favorite;
      await put(STORES.tracks, t);
      toast("Favorit", t.favorite ? "Markerad." : "Avmarkerad.");
      render();
    };

    $("#btnInsertHook").onclick = () => insertAtCursor($("#edLyrics"), "\n\n[HOOK]\n");
    $("#btnInsertVerse").onclick = () => insertAtCursor($("#edLyrics"), "\n\n[VERS]\n");
    $("#btnInsertBridge").onclick = () => insertAtCursor($("#edLyrics"), "\n\n[BRYGGA]\n");
    $("#btnToWizard").onclick = () => setRoute("wizard");
    $("#btnOpenBank").onclick = () => setRoute("bank");

    $("#btnSnap").onclick = async () => {
      const label = prompt("Snapshot-namn?", `Snapshot ${new Date().toLocaleString()}`) || "";
      const s = {
        id: uuid(),
        track_id: track.id,
        created_at: nowISO(),
        label: label.trim(),
        title: $("#edTitle").value.trim(),
        status: $("#edStatus").value,
        lyrics: $("#edLyrics").value
      };
      await put(STORES.snapshots, s);
      toast("Snapshot", "Sparad.");
      render();
    };

    $("#btnExportMd").onclick = async () => {
      const ctx2 = await getContext();
      const t = ctx2.track;
      const md = `# ${t.title}\n\nStatus: ${t.status}\n\n---\n\n${t.lyrics}\n`;
      downloadText(`${slugify(t.title)}.md`, md);
      toast("Export", "Markdown nedladdad.");
    };

    // restore/delete snapshots
    $$("#view [data-restore]").forEach(btn => {
      btn.onclick = async () => {
        const s = await getById(STORES.snapshots, btn.dataset.restore);
        if(!s) return;
        $("#edTitle").value = s.title || "";
        $("#edStatus").value = s.status || "continue";
        $("#edLyrics").value = s.lyrics || "";
        await saveDebounced();
        toast("Återställt", "Snapshot laddad i editorn.");
      };
    });
    $$("#view [data-del-snap]").forEach(btn => {
      btn.onclick = async () => {
        await del(STORES.snapshots, btn.dataset.delSnap);
        toast("Raderat", "Snapshot borttagen.");
        render();
      };
    });

    // recommendation search
    const recSearch = $("#recSearch");
    recSearch.addEventListener("input", debounce(async () => {
      const q = recSearch.value.trim().toLowerCase();
      const bank = await loadBankCache();
      let list = recommendBankLines(bank, track, ctx);
      if(q){
        list = bank.filter(r => (r.base_text||"").toLowerCase().includes(q)).slice(0, 16);
      }
      $("#recList").innerHTML = list.map(r => bankItemHtml(r, true)).join("");
      bindBankInsertButtons("#recList");
    }, 200));

    bindBankInsertButtons("#recList");
  }

  function insertAtCursor(textarea, text){
    const start = textarea.selectionStart ?? textarea.value.length;
    const end = textarea.selectionEnd ?? textarea.value.length;
    const v = textarea.value;
    textarea.value = v.slice(0,start) + text + v.slice(end);
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + text.length;
    textarea.dispatchEvent(new Event("input", {bubbles:true}));
  }

  function slugify(s){
    return (s||"untitled").toLowerCase()
      .replaceAll("å","a").replaceAll("ä","a").replaceAll("ö","o")
      .replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60) || "untitled";
  }

  function downloadText(filename, text){
    const blob = new Blob([text], {type:"text/plain;charset=utf-8"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(()=>{URL.revokeObjectURL(url); a.remove();}, 50);
  }

  function bankItemHtml(r, showInsert){
    const themes = (r.themes||[]).slice(0,3).map(t => `<span class="chip chip--accent">${escapeHtml(t)}</span>`).join(" ");
    const type = r.type ? `<span class="chip chip--good">${escapeHtml(r.type)}</span>` : "";
    return `
      <div class="item">
        <div class="item__main">
          <div class="item__title">${type} ${themes}</div>
          <div class="item__text">${escapeHtml(r.base_text || "")}</div>
        </div>
        <div class="item__actions">
          ${showInsert ? `<button class="iconBtn" data-insert-line="${escapeHtml(r.id)}">＋</button>` : ""}
          <button class="iconBtn" data-copy-line="${escapeHtml(r.id)}">Copy</button>
        </div>
      </div>
    `;
  }

  function bindBankInsertButtons(rootSel){
    const root = $(rootSel);
    if(!root) return;
    $$("[data-insert-line]", root).forEach(btn => {
      btn.onclick = async () => {
        const id = btn.dataset.insertLine;
        const bank = await loadBankCache();
        const row = bank.find(x => x.id === id);
        if(!row) return;
        const ctx = await getContext();
        if(!ctx.track){
          toast("Spår saknas", "Välj/Skapa ett spår först.");
          return;
        }
        // insert into editor if present, else append to track lyrics
        const ed = $("#edLyrics");
        if(ed) insertAtCursor(ed, row.base_text + "\n");
        else{
          const t = await getById(STORES.tracks, ctx.track.id);
          t.lyrics = (t.lyrics||"") + "\n" + row.base_text;
          await put(STORES.tracks, t);
          toast("Infogat", "Rad lades till i spåret.");
        }
      };
    });
    $$("[data-copy-line]", root).forEach(btn => {
      btn.onclick = async () => {
        const id = btn.dataset.copyLine;
        const bank = await loadBankCache();
        const row = bank.find(x => x.id === id);
        if(!row) return;
        await navigator.clipboard.writeText(row.base_text || "");
        toast("Kopierat", "Rad kopierad.");
      };
    });
  }

  function recommendBankLines(bank, track, ctx){
    const lyrics = (track?.lyrics || "").toLowerCase();
    const title = (track?.title || "").toLowerCase();
    const keys = new Set();
    (lyrics + " " + title).split(/\s+/).forEach(w => {
      const ww = w.replace(/[^\p{L}\p{N}_/]+/gu,"").toLowerCase();
      if(ww.length >= 5) keys.add(ww);
    });
    const keyArr = Array.from(keys).slice(0, 18);
    let scored = bank.map(r => {
      const t = (r.base_text||"").toLowerCase();
      let s = 0;
      if(r.themes?.some(th => (ctx.dna||"").toLowerCase().includes(th.toLowerCase()))) s += 2;
      keyArr.forEach(k => { if(t.includes(k)) s += 1; });
      if(r.type === "hookline") s += 1;
      if(r.ratings?.impact) s += (r.ratings.impact-3)*0.2;
      return {r, s};
    });
    scored.sort((a,b) => b.s - a.s);
    return scored.slice(0, 14).map(x => x.r);
  }

  async function renderBank(){
    const ctx = await getContext();
    setBreadcrumb({viewLabel:"Bank"});
    const view = $("#view");

    const bankCnt = await bankCount();

    view.innerHTML = `
      <div class="grid">
        ${card({
          title:"Bank",
          sub:"Sök, plocka in i spår, import/export. Banken ligger lokalt i din browser.",
          actionsHtml: `
            <button class="btn btn--ghost" id="btnImportCsv">Import CSV</button>
            <button class="btn btn--ghost" id="btnExportBank">Export JSON</button>
            <button class="btn" id="btnReSeed">Re-seed</button>
          `,
          bodyHtml: `
            <div class="row" style="margin-top:12px;">
              <div class="field">
                <div class="label">Sök</div>
                <input class="input" id="bankSearch" placeholder="Sök i banken…" value="${escapeHtml(state.bank_query)}" />
              </div>
              <div class="field">
                <div class="label">Tema</div>
                <select class="select" id="bankTheme">
                  ${["Alla","Sverige","Neuro","Musik","Mörker","Trots","Relation","Kamp","Kreativitet"].map(t => `<option ${t===state.bank_theme ? "selected":""}>${t}</option>`).join("")}
                </select>
              </div>
              <div class="field">
                <div class="label">Info</div>
                <div class="kpi__item">Rader: ${bankCnt}</div>
              </div>
            </div>
            <div class="list" id="bankList" style="margin-top:14px;"></div>
          `
        })}
      </div>
    `;

    const bank = await loadBankCache();
    const doSearch = async () => {
      const q = ($("#bankSearch").value || "").trim().toLowerCase();
      const th = $("#bankTheme").value;
      state.bank_query = q;
      state.bank_theme = th;

      let rows = bank;
      if(th !== "Alla"){
        rows = rows.filter(r => (r.themes||[]).includes(th));
      }
      if(q){
        rows = rows.filter(r => (r.base_text||"").toLowerCase().includes(q));
      }

      const slice = rows.slice(0, 60);
      $("#bankList").innerHTML = slice.map(r => bankItemHtml(r, true)).join("") || `<div class="item"><div class="item__main"><div class="item__meta">Inga träffar.</div></div></div>`;
      bindBankInsertButtons("#bankList");
    };

    $("#bankSearch").addEventListener("input", debounce(doSearch, 180));
    $("#bankTheme").addEventListener("change", doSearch);
    await doSearch();

    $("#btnImportCsv").onclick = () => openImportCsvModal();
    $("#btnExportBank").onclick = async () => {
      const all = await getAll(STORES.bank);
      downloadText(`dbtsOS_bank_${new Date().toISOString().slice(0,10)}.json`, JSON.stringify(all, null, 2));
      toast("Export", "Bank exporterad (JSON).");
    };
    $("#btnReSeed").onclick = async () => {
      if(!confirm("Detta lägger in seed-bank igen om banken är tom. Vill du även rensa banken först?")) return;
      if(confirm("Rensa hela banken först?")){
        await clearStore(STORES.bank);
        state.bank_cache = null;
      }
      await importSeedBankIfNeeded();
      state.bank_cache = null;
      await loadBankCache(true);
      render();
    };
  }

  function openImportCsvModal(){
    openModal({
      title: "Importera CSV/JSON till Bank",
      okText: "Importera",
      bodyHtml: `
        <div class="field">
          <div class="label">Fil</div>
          <input class="input" type="file" id="impFile" accept=".csv,.json" />
          <div class="label" style="margin-top:8px;color:var(--muted2)">Tips: använd <code>data/bank_template.csv</code> som mall.</div>
        </div>
        <div class="field">
          <div class="label">Läge</div>
          <select class="select" id="impMode">
            <option value="append" selected>Lägg till</option>
            <option value="replace">Ersätt (rensa först)</option>
          </select>
        </div>
      `,
      onOk: async () => {
        const file = $("#impFile").files?.[0];
        if(!file) throw new Error("Välj en fil.");
        const mode = $("#impMode").value;
        if(mode === "replace"){
          await clearStore(STORES.bank);
          state.bank_cache = null;
        }
        const text = await file.text();
        let rows = [];
        if(file.name.toLowerCase().endsWith(".json")){
          rows = JSON.parse(text);
        } else {
          rows = parseCsvBank(text);
        }
        await importBankRows(rows);
        state.bank_cache = null;
        toast("Import", `Klart: ${rows.length} rader.`);
        render();
      }
    });
  }

  function parseCsvBank(text){
    const lines = text.split(/\r?\n/).filter(Boolean);
    if(lines.length < 2) return [];
    const header = splitCsvLine(lines[0]).map(h => h.trim());
    const idx = (name) => header.indexOf(name);
    const out = [];
    for(let i=1;i<lines.length;i++){
      const cols = splitCsvLine(lines[i]);
      if(cols.length < 2) continue;
      const base_text = cols[idx("base_text")] ?? cols[cols.length-1];
      if(!base_text || base_text.trim().length < 6) continue;
      const id = (cols[idx("id")] || "").trim() || uuid();
      const themes = ((cols[idx("themes")]||"").split("|").map(s=>s.trim()).filter(Boolean)).slice(0,3);
      out.push({
        id,
        created_at: nowISO(),
        type: (cols[idx("type")] || "bar").trim() || "bar",
        themes,
        style_tags: ((cols[idx("style_tags")]||"").split("|").map(s=>s.trim()).filter(Boolean)).slice(0,4),
        technique_tags: ((cols[idx("technique_tags")]||"").split("|").map(s=>s.trim()).filter(Boolean)).slice(0,4),
        ratings: {
          impact: +(cols[idx("impact")]||3) || 3,
          novelty: +(cols[idx("novelty")]||3) || 3,
          singability: +(cols[idx("singability")]||3) || 3,
          clarity: +(cols[idx("clarity")]||3) || 3
        },
        base_text: base_text.trim(),
        rewrite_v1:"",
        rewrite_v2:"",
        rewrite_v3:"",
        rewrite_v4:"",
        suno_notes:{persona_hint:"TredAI / dbts", reuse_prompt_hint:"", exclude_hint:"", pronunciation_hint:""},
        usage:{world_id:"", profile_id:"", album_id:"", track_ids:[]}
      });
    }
    return out;
  }

  function splitCsvLine(line){
    // Very small CSV parser (handles quotes)
    const out = [];
    let cur="", inQ=false;
    for(let i=0;i<line.length;i++){
      const ch=line[i];
      if(ch === '"' ){
        if(inQ && line[i+1] === '"'){ cur += '"'; i++; }
        else inQ = !inQ;
        continue;
      }
      if(ch === "," && !inQ){
        out.push(cur); cur=""; continue;
      }
      cur += ch;
    }
    out.push(cur);
    return out;
  }

  async function importBankRows(rows){
    if(!rows?.length) return;
    const chunkSize = 400;
    for(let i=0;i<rows.length;i+=chunkSize){
      const chunk = rows.slice(i, i+chunkSize);
      const t = db.transaction(STORES.bank, "readwrite");
      const store = t.objectStore(STORES.bank);
      await new Promise((resolve, reject) => {
        chunk.forEach(obj => store.put(obj));
        t.oncomplete = resolve;
        t.onerror = () => reject(t.error);
        t.onabort = () => reject(t.error);
      });
      if(i % (chunkSize*3) === 0) await sleep(8);
    }
  }

  async function renderVault(){
    const ctx = await getContext();
    setBreadcrumb({viewLabel:"Vault"});
    const view = $("#view");
    const docs = (await getAll(STORES.vault)).sort((a,b)=> (b.updated_at||"").localeCompare(a.updated_at||""));

    view.innerHTML = `
      <div class="grid">
        ${card({
          title:"Vault",
          sub:"Klistra in gamla texter. Spara. Bryt ner till bankrader eller skapa spår.",
          actionsHtml:`<button class="btn" id="btnNewDoc">＋ Ny text</button>`,
          bodyHtml: `
            <div style="margin-top:12px;">${contextSelectorHtml(ctx)}</div>
            <hr class="sep"/>
            <div class="list" id="vaultList">
              ${docs.length ? docs.slice(0, 30).map(d => `
                <div class="item">
                  <div class="item__main">
                    <div class="item__title">${escapeHtml(d.title || "(utan titel)")}</div>
                    <div class="item__meta">${new Date(d.updated_at||Date.now()).toLocaleString()}</div>
                    <div class="item__text">${escapeHtml((d.body||"").slice(0, 280))}${(d.body||"").length>280 ? "…" : ""}</div>
                  </div>
                  <div class="item__actions">
                    <button class="iconBtn" data-open-doc="${d.id}">Öppna</button>
                    <button class="iconBtn" data-to-track="${d.id}">→ Spår</button>
                    <button class="iconBtn" data-to-bank="${d.id}">→ Bank</button>
                    <button class="iconBtn" data-del-doc="${d.id}">Radera</button>
                  </div>
                </div>
              `).join("") : `<div class="item"><div class="item__main"><div class="item__meta">Inget i vault än.</div></div></div>`}
            </div>
          `
        })}
      </div>
    `;

    await mountContextSelector();

    $("#btnNewDoc").onclick = () => openDocEditor(null);

    $$("[data-open-doc]").forEach(b => b.onclick = async () => openDocEditor(b.dataset.openDoc));
    $$("[data-del-doc]").forEach(b => b.onclick = async () => {
      if(!confirm("Radera dokument?")) return;
      await del(STORES.vault, b.dataset.delDoc);
      toast("Raderat", "Dokument borttaget.");
      render();
    });

    $$("[data-to-track]").forEach(b => b.onclick = async () => {
      const doc = await getById(STORES.vault, b.dataset.toTrack);
      if(!doc) return;
      const id = uuid();
      await put(STORES.tracks, {
        id,
        album_id: state.album_id,
        title: doc.title || "Vault → Spår",
        status: "continue",
        favorite: false,
        dna: "",
        anti: "",
        lyrics: doc.body || "",
        links: {suno:"", spotify:"", youtube:""},
        updated_at: nowISO()
      });
      state.track_id = id;
      await kvSet("track_id", id);
      toast("Skapat", "Spår skapat från vault.");
      setRoute("editor");
    });

    $$("[data-to-bank]").forEach(b => b.onclick = async () => {
      const doc = await getById(STORES.vault, b.dataset.toBank);
      if(!doc) return;
      const lines = (doc.body||"").split(/\r?\n/).map(s=>s.trim()).filter(s => s.length>=8 && s.length<=180);
      if(lines.length===0){
        toast("Tomt", "Inga rader hittades.");
        return;
      }
      const rows = lines.slice(0, 800).map(txt => ({
        id: uuid(),
        created_at: nowISO(),
        type: "bar",
        themes: [],
        style_tags: [],
        technique_tags: [],
        ratings: {impact:3, novelty:3, singability:3, clarity:3},
        base_text: txt,
        rewrite_v1:"",
        rewrite_v2:"",
        rewrite_v3:"",
        rewrite_v4:"",
        suno_notes:{persona_hint:"TredAI / dbts", reuse_prompt_hint:"", exclude_hint:"", pronunciation_hint:""},
        usage:{world_id:"", profile_id:"", album_id:"", track_ids:[]}
      }));
      await importBankRows(rows);
      state.bank_cache = null;
      toast("Bank", `Lade till ${rows.length} rader från vault.`);
    });
  }

  async function openDocEditor(id){
    const doc = id ? await getById(STORES.vault, id) : {id: uuid(), title:"", body:"", updated_at: nowISO()};
    openModal({
      title: id ? "Redigera Vault-text" : "Ny Vault-text",
      okText: "Spara",
      bodyHtml: `
        <div class="field">
          <div class="label">Titel</div>
          <input class="input" id="docTitle" value="${escapeHtml(doc.title || "")}" />
        </div>
        <div class="field">
          <div class="label">Text</div>
          <textarea class="textarea" id="docBody" placeholder="Klistra in text här…">${escapeHtml(doc.body || "")}</textarea>
        </div>
      `,
      onOk: async () => {
        doc.title = $("#docTitle").value.trim();
        doc.body = $("#docBody").value;
        await put(STORES.vault, doc);
        toast("Sparat", "Vault uppdaterad.");
        render();
      }
    });
  }

  async function renderWizard(){
    const ctx = await getContext();
    setBreadcrumb({viewLabel:"Wizard"});
    const view = $("#view");
    const track = ctx.track;

    const bank = await loadBankCache();
    const rec = track ? recommendBankLines(bank, track, ctx) : [];

    const dna = ctx.dna || "";
    const anti = ctx.anti || "";

    view.innerHTML = `
      <div class="grid">
        ${card({
          title:"Wizard",
          sub:"Bygger prompts som respekterar DNA/ANTI och din takt/prosodi. Copy → klistra i ChatGPT/Suno/NotebookLM.",
          actionsHtml: `<button class="btn btn--ghost" id="btnCopyPrompt">Copy</button><button class="btn" id="btnApplyDraft">→ Lägg i spår</button>`,
          bodyHtml: `
            <div style="margin-top:12px;">${contextSelectorHtml(ctx)}</div>
            <hr class="sep"/>

            <div class="split">
              <div>
                <div class="row">
                  <div class="field">
                    <div class="label">Läge</div>
                    <select class="select" id="wMode">
                      ${["Draft","Refine","QA","Suno Pack","Debug"].map(m => `<option ${m===state.wizard_mode ? "selected":""}>${m}</option>`).join("")}
                    </select>
                  </div>
                  <div class="field">
                    <div class="label">Tema (valfritt)</div>
                    <input class="input" id="wTheme" placeholder="t.ex. Sverige-i-tiden, trots, ADHD som rytm-maskin…" value="${escapeHtml(state.wizard_theme)}" />
                  </div>
                </div>

                <div class="row" style="margin-top:10px;">
                  <div class="field">
                    <div class="label">Style (Suno/Prompt)</div>
                    <input class="input" id="wStyle" value="${escapeHtml(state.wizard_style)}" />
                  </div>
                </div>
                <div class="row" style="margin-top:10px;">
                  <div class="field">
                    <div class="label">Exclude / Anti</div>
                    <input class="input" id="wExclude" value="${escapeHtml(state.wizard_exclude)}" />
                  </div>
                </div>

                <div class="field" style="margin-top:10px;">
                  <div class="label">Prompt</div>
                  <textarea class="textarea" id="wOut" readonly></textarea>
                </div>

                <div class="row" style="margin-top:10px;">
                  <button class="btn btn--ghost" id="btnRegenerate">↻ Bygg om</button>
                  <button class="btn btn--ghost" id="btnOpenEditor">✍️ Öppna spår</button>
                  <button class="btn" id="btnCopySuno">📋 Copy Suno-pack</button>
                </div>
              </div>

              <div>
                ${card({
                  title:"Bank-remsor (för wizard)",
                  sub:"Dra in inspiration eller låt wizard använda dem som constraints.",
                  actionsHtml:`<button class="btn btn--ghost" id="btnCopyRec">Copy 10</button>`,
                  bodyHtml: `
                    <div class="list" id="wizRec">
                      ${rec.slice(0,10).map(r => bankItemHtml(r, false)).join("") || `<div class="item"><div class="item__main"><div class="item__meta">Välj spår för rekommendationer.</div></div></div>`}
                    </div>
                  `
                })}

                ${card({
                  title:"DNA / Anti (ärvda)",
                  sub:"Detta är vad systemet faktiskt skickar in som regler.",
                  bodyHtml: `
                    <div class="field" style="margin-top:12px;">
                      <div class="label">DNA</div>
                      <textarea class="textarea" readonly style="min-height:120px;">${escapeHtml(dna || "(tomt)")}</textarea>
                    </div>
                    <div class="field">
                      <div class="label">ANTI</div>
                      <textarea class="textarea" readonly style="min-height:120px;">${escapeHtml(anti || "(tomt)")}</textarea>
                    </div>
                  `
                })}
              </div>
            </div>
          `
        })}
      </div>
    `;

    await mountContextSelector();

    const update = () => {
      state.wizard_mode = $("#wMode").value;
      state.wizard_theme = $("#wTheme").value.trim();
      state.wizard_style = $("#wStyle").value.trim();
      state.wizard_exclude = $("#wExclude").value.trim();
      $("#wOut").value = buildWizardPrompt(state.wizard_mode, ctx, rec.slice(0,10));
    };

    $("#wMode").onchange = update;
    $("#wTheme").oninput = debounce(update, 120);
    $("#wStyle").oninput = debounce(update, 120);
    $("#wExclude").oninput = debounce(update, 120);
    $("#btnRegenerate").onclick = update;
    update();

    $("#btnOpenEditor").onclick = () => setRoute("editor");

    $("#btnCopyPrompt").onclick = async () => {
      await navigator.clipboard.writeText($("#wOut").value);
      toast("Kopierat", "Prompt kopierad.");
    };

    $("#btnCopyRec").onclick = async () => {
      const txt = rec.slice(0,10).map(r => "- " + (r.base_text||"")).join("\n");
      await navigator.clipboard.writeText(txt);
      toast("Kopierat", "10 rader kopierade.");
    };

    $("#btnApplyDraft").onclick = async () => {
      const mode = $("#wMode").value;
      if(mode !== "Draft"){
        toast("Tips", "Byt läge till Draft om du vill få text att stoppa in.");
        return;
      }
      const out = $("#wOut").value;
      const draft = extractDraftBlock(out);
      if(!draft){
        toast("Ingen draft", "Prompten innehåller ingen draft-block än. Kopiera till ChatGPT och be den returnera draft i formatet som prompten kräver.");
        return;
      }
      const t = await getById(STORES.tracks, state.track_id);
      if(!t) return;
      t.lyrics = (t.lyrics || "").trim() + "\n\n" + draft.trim() + "\n";
      await put(STORES.tracks, t);
      toast("Infogat", "Draft lades in i spåret.");
      setRoute("editor");
    };

    $("#btnCopySuno").onclick = async () => {
      const pack = buildSunoPack(ctx);
      await navigator.clipboard.writeText(pack);
      toast("Kopierat", "Suno-pack kopierat.");
    };
  }

  function buildWizardPrompt(mode, ctx, recRows){
    const track = ctx.track;
    const title = track?.title || "(ingen titel)";
    const lyrics = (track?.lyrics || "").trim();
    const theme = state.wizard_theme ? `\nTEMA: ${state.wizard_theme}\n` : "";
    const dna = (ctx.dna || "").trim();
    const anti = (ctx.anti || "").trim();
    const style = state.wizard_style || "";
    const exclude = state.wizard_exclude || "";

    const recText = recRows?.length
      ? recRows.map(r => `- ${r.base_text}`).join("\n")
      : "- (ingen bank-rekommendation – välj spår för att aktivera)";

    const baseRules = `
ICKE-FÖRHANDLINGSBART:
- Språk: Svenska.
- Prosodi: sjungbart i 12/8 (trioler) om inte annat anges.
- Inga klichéer (självhjälp, “resan”, “hjärtat/själen”, etc).
- Kall men fysisk känsla: konkreta detaljer och kroppsliga reaktioner.
- Följ DNA och undvik ANTI.

DNA (ärvda):
${dna || "(tomt)"}

ANTI (ärvda):
${anti || "(tomt)"}

STYLE (för Suno/arrangemang):
${style}

EXCLUDE (extra):
${exclude}

BANK-REMSOR (valfri inspiration/constraints):
${recText}
`.trim();

    if(mode === "Draft"){
      return `
DU ÄR: “POETEN + MIXTEKNIKERN (DBTS)”
MÅL: Skapa en första skrivbar draft till spåret.

SPÅR: ${title}
${theme}

${baseRules}

INPUT (befintlig text, kan vara tom):
${lyrics || "(tomt)"}

OUTPUTFORMAT (KRAV):
Returnera exakt detta block – inget mer:

[DRAFT]
[Intro]
...
[Vers 1]
...
[Refräng]
...
[Vers 2]
...
[Outro]
...
[/DRAFT]
`.trim();
    }

    if(mode === "Refine"){
      return `
DU ÄR: “REDAKTÖR + PROSODI-LINTER”
MÅL: Finputsning utan att tappa röst.

SPÅR: ${title}
${theme}

${baseRules}

INPUT (text att förbättra):
${lyrics || "(klistra in lyrics i spåret först)"}

OUTPUTFORMAT:
1) Förbättrad version (hela texten)
2) 10 konkreta ändringar (bullet list)
3) 5 alternativa punchlines/hooks
`.trim();
    }

    if(mode === "QA"){
      return `
DU ÄR: “OBJEKTIV GRANSKARE”
MÅL: Hitta svagheter, klichéer, rytmproblem, otydligheter.

SPÅR: ${title}
${theme}

${baseRules}

INPUT:
${lyrics || "(klistra in lyrics i spåret först)"}

OUTPUTFORMAT:
- Fel/krockar mot DNA/ANTI (max 12)
- Prosodi/flow-notes (12/8): var det snubblar
- Rim/konsonans: var det kan skärpas
- 3 förbättringsplaner (A/B/C)
`.trim();
    }

    if(mode === "Debug"){
      return `
DU ÄR: “FELSÖKARE”
MÅL: Om texten känns 'off' – hitta varför och ge kirurgiska fixar.

SPÅR: ${title}
${theme}

${baseRules}

INPUT:
${lyrics || "(klistra in lyrics i spåret först)"}

OUTPUTFORMAT:
1) Diagnos (max 8 punkter)
2) Patch-notes (konkreta text-byten) i format:
   - BYT: "gammalt"
     MOT: "nytt"
3) Snabbtest: 4 rader som bevisar att patchen funkar
`.trim();
    }

    // Suno pack
    return buildSunoPack(ctx);
  }

  function buildSunoPack(ctx){
    const track = ctx.track;
    const title = track?.title || "Untitled";
    const lyrics = (track?.lyrics || "").trim();
    const dna = (ctx.dna || "").trim();
    const anti = (ctx.anti || "").trim();

    return `
SUNO PACK – dbtsOS v9

TITLE:
${title}

STYLE PROMPT:
${state.wizard_style || "(lägg style här)"}

EXCLUDE:
${state.wizard_exclude || ""}

DNA (constraints):
${dna || "(tomt)"}

ANTI (avoid):
${anti || "(tomt)"}

LYRICS:
${lyrics || "(tomt)"}
`.trim();
  }

  function extractDraftBlock(text){
    const m = text.match(/\[DRAFT\]([\s\S]*?)\[\/DRAFT\]/i);
    return m ? m[1].trim() : null;
  }

  async function renderSettings(){
    const ctx = await getContext();
    setBreadcrumb({viewLabel:"Settings"});
    const view = $("#view");

    const bankCnt = await bankCount();
    const tracksCnt = (await getAll(STORES.tracks)).length;
    const vaultCnt = (await getAll(STORES.vault)).length;

    view.innerHTML = `
      <div class="grid">
        ${card({
          title:"Backup & dataflytt (mobil ↔ dator)",
          sub:"Allt sparas lokalt. Export/import är din sync utan backend.",
          actionsHtml:`<button class="btn" id="btnExportAll">⬇ Export</button><button class="btn btn--ghost" id="btnImportAll">⬆ Import</button>`,
          bodyHtml: `
            <div class="kpi" style="margin-top:12px;">
              <div class="kpi__item">Bank: ${bankCnt}</div>
              <div class="kpi__item">Tracks: ${tracksCnt}</div>
              <div class="kpi__item">Vault: ${vaultCnt}</div>
            </div>
            <div class="field" style="margin-top:12px;">
              <div class="label">Obs</div>
              <div class="label" style="color:var(--muted2)">Export blir en fil du kan spara i Drive och importera på annan enhet.</div>
            </div>
          `
        })}

        ${card({
          title:"App-inställningar",
          sub:"Små saker som gör flödet snabbare och mindre 'billigt'.",
          actionsHtml:`<button class="btn btn--ghost" id="btnResetUi">Reset UI</button>`,
          bodyHtml: `
            <div class="row" style="margin-top:12px;">
              <div class="field">
                <div class="label">Reduced motion</div>
                <select class="select" id="selMotion">
                  <option value="0" ${state.reduced_motion ? "" : "selected"}>Av</option>
                  <option value="1" ${state.reduced_motion ? "selected" : ""}>På</option>
                </select>
              </div>
              <div class="field">
                <div class="label">Seed bank</div>
                <button class="btn" id="btnSeed2">Importera seed (om tom)</button>
              </div>
              <div class="field">
                <div class="label">Farligt</div>
                <button class="btn btn--ghost" id="btnNuke">Rensa ALLT</button>
              </div>
            </div>
          `
        })}

        ${card({
          title:"Deploy check",
          sub:"Cloudflare Pages ska vara 'no build'. Service Worker kräver https.",
          bodyHtml: `
            <div class="field" style="margin-top:12px;">
              <div class="label">Service Worker</div>
              <div class="kpi__item" id="swStatus">kollar…</div>
            </div>
            <div class="field">
              <div class="label">Seed filer</div>
              <div class="kpi__item">data/seed_bank.json</div>
              <div class="kpi__item">data/seed_bank.csv</div>
            </div>
          `
        })}
      </div>
    `;

    $("#btnExportAll").onclick = exportAllData;
    $("#btnImportAll").onclick = importAllDataModal;

    $("#btnSeed2").onclick = async () => {
      await importSeedBankIfNeeded();
      state.bank_cache = null;
      render();
    };

    $("#selMotion").onchange = async () => {
      state.reduced_motion = $("#selMotion").value === "1";
      await kvSet("reduced_motion", state.reduced_motion);
      toast("Sparat", "UI-inställning uppdaterad.");
    };

    $("#btnResetUi").onclick = async () => {
      await kvSet("bank_query", "");
      await kvSet("bank_theme", "Alla");
      toast("Reset", "UI reset.");
    };

    $("#btnNuke").onclick = async () => {
      if(!confirm("Rensa ALLT lokalt? (bank + spår + vault + settings)")) return;
      await Promise.all(Object.values(STORES).map(s => clearStore(s)));
      state.bank_cache = null;
      toast("Rensat", "All data borttagen. Laddar om…");
      location.reload();
    };

    // SW status
    const swStatus = $("#swStatus");
    if("serviceWorker" in navigator){
      swStatus.textContent = (location.protocol === "https:" || location.hostname === "localhost")
        ? "stöd finns (https ok)"
        : "blockerad (kräver https / localhost)";
    } else {
      swStatus.textContent = "ingen support";
    }
  }

  async function exportAllData(){
    const payload = {
      exported_at: nowISO(),
      version: 9,
      meta: await getAll(STORES.meta),
      worlds: await getAll(STORES.worlds),
      profiles: await getAll(STORES.profiles),
      albums: await getAll(STORES.albums),
      tracks: await getAll(STORES.tracks),
      bank: await getAll(STORES.bank),
      vault: await getAll(STORES.vault),
      snapshots: await getAll(STORES.snapshots)
    };
    downloadText(`dbtsOS_backup_${new Date().toISOString().slice(0,10)}.json`, JSON.stringify(payload, null, 2));
    toast("Backup", "Export klar.");
  }

  function importAllDataModal(){
    openModal({
      title: "Importera backup",
      okText: "Importera",
      bodyHtml: `
        <div class="field">
          <div class="label">Backup-fil (.json)</div>
          <input class="input" type="file" id="bkFile" accept=".json" />
        </div>
        <div class="field">
          <div class="label">Läge</div>
          <select class="select" id="bkMode">
            <option value="merge" selected>Merge (lägg till/uppdatera)</option>
            <option value="replace">Replace (rensa först)</option>
          </select>
        </div>
      `,
      onOk: async () => {
        const file = $("#bkFile").files?.[0];
        if(!file) throw new Error("Välj en fil.");
        const mode = $("#bkMode").value;
        const data = JSON.parse(await file.text());
        await importAllData(data, mode);
        toast("Import", "Klart. Laddar om…");
        setTimeout(()=>location.reload(), 400);
      }
    });
  }

  async function importAllData(data, mode){
    if(mode === "replace"){
      await Promise.all(Object.values(STORES).map(s => clearStore(s)));
    }
    const importStore = async (storeName, arr) => {
      if(!Array.isArray(arr) || arr.length===0) return;
      const chunkSize = 400;
      for(let i=0;i<arr.length;i+=chunkSize){
        const chunk = arr.slice(i, i+chunkSize);
        const t = db.transaction(storeName, "readwrite");
        const store = t.objectStore(storeName);
        await new Promise((resolve, reject) => {
          chunk.forEach(obj => store.put(obj));
          t.oncomplete = resolve;
          t.onerror = () => reject(t.error);
          t.onabort = () => reject(t.error);
        });
        await sleep(8);
      }
    };
    await importStore(STORES.meta, data.meta);
    await importStore(STORES.worlds, data.worlds);
    await importStore(STORES.profiles, data.profiles);
    await importStore(STORES.albums, data.albums);
    await importStore(STORES.tracks, data.tracks);
    await importStore(STORES.bank, data.bank);
    await importStore(STORES.vault, data.vault);
    await importStore(STORES.snapshots, data.snapshots);
  }

  async function render(){
    try{
      setBreadcrumb({viewLabel: state.route});
      const view = $("#view");
      if(!view) return;

      if(state.route === "home") return await renderHome();
      if(state.route === "editor") return await renderEditor();
      if(state.route === "wizard") return await renderWizard();
      if(state.route === "bank") return await renderBank();
      if(state.route === "vault") return await renderVault();
      if(state.route === "settings") return await renderSettings();
      return await renderHome();
    } catch(err){
      console.error(err);
      $("#view").innerHTML = `
        <div class="grid">
          ${card({title:"Krasch", sub:"Något gick snett. Kolla Console för detaljer.", bodyHtml:`<pre style="white-space:pre-wrap;color:var(--muted);font-family:var(--mono);">${escapeHtml(err?.stack || err?.message || String(err))}</pre>`})}
        </div>
      `;
      toast("Fel", err?.message || "Okänt fel");
    }
  }

  // ---------- Global wiring ----------
  function wireNav(){
    $$(".nav__item, .bottomnav__item").forEach(btn => {
      btn.addEventListener("click", () => setRoute(btn.dataset.route));
    });

    $("#btnQuickAddTrack").onclick = createTrackQuick;
    $("#btnQuickWizard").onclick = () => setRoute("wizard");
    $("#btnQuickBackup").onclick = exportAllData;
  }

  // ---------- Boot ----------
  async function boot(){
    // catch silent errors
    window.addEventListener("error", (e) => console.error("window.error", e.error || e.message));
    window.addEventListener("unhandledrejection", (e) => console.error("unhandledrejection", e.reason));

    await openDb();

    // restore ui settings
    state.reduced_motion = await kvGet("reduced_motion", false);

    await ensureDefaults();
    await importSeedBankIfNeeded();

    // initial route
    state.route = routeFromHash();
    syncNav(state.route);

    wireNav();

    window.addEventListener("hashchange", () => {
      state.route = routeFromHash();
      syncNav(state.route);
      render();
    });

    // register SW (only on https/localhost)
    if("serviceWorker" in navigator && (location.protocol==="https:" || location.hostname==="localhost")){
      try{
        await navigator.serviceWorker.register("./sw.js", {scope:"./"});
      } catch(err){
        console.warn("SW register failed", err);
      }
    }

    render();
    console.info("dbtsOS v9 boot ok");
  }

  document.addEventListener("DOMContentLoaded", boot);

})();
