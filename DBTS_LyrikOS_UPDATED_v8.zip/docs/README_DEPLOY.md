# Deploya LyrikOS Gratis

Denna guide visar hur du snabbt publicerar din LyrikOS-app på en egen subdomän på **Cloudflare Pages**. Du behöver bara ett gratis Cloudflare-konto och kontroll över DNS för din domän (t.ex. `dbts.se`).

## 1. Förbered git-repo

1. Skapa ett nytt publikt repo på GitHub, t.ex. `lyrikos`. Du kan använda GitHub‑webben.
2. Ladda upp innehållet i mappen `maximal_optimal_app` till rotkatalogen i repositoriet. Om du inte har git installerat kan du bara skapa filerna via GitHub webeditor.

## 2. Skapa ett Pages-projekt

1. Gå till [Cloudflare Pages](https://pages.cloudflare.com/) och logga in.
2. Klicka **Create a project** och välj ditt GitHub‑konto. Välj det repo du nyss skapade.
3. Behåll bygginställningen som **Framework: None** (statisk sajt). Build Command och Output Directory lämnas tomma.
4. Klicka **Save and Deploy**. Efter några sekunder får du en `.pages.dev`-adress (t.ex. `lyrikos.pages.dev`).

## 3. Koppla subdomän

1. Logga in på Cloudflare (där din domän är konfigurerad). Gå till din domän (t.ex. `dbts.se`).
2. Under DNS > Records klickar du **Add record**:
   - Typ: `CNAME`
   - Namn: `lyrik` (eller vad du vill att subdomänen ska heta)
   - Target: den `.pages.dev`-adress du fick (t.ex. `lyrikos.pages.dev`)
   - TTL: Auto
3. Spara. Efter några minuter fungerar adressen `https://lyrik.dbts.se` (ersätt med din domän).

Du behöver **inte** flytta namnservrar från Google Workspace. Håll bara dina befintliga MX‑poster intakta för att mejlen ska fungera. CNAME påverkar bara subdomänen `lyrik`.

## 4. Lägg till offline‑cache (frivilligt)

Appen har en service worker som gör att den kan installeras och köras offline. Detta kräver dock https. När din sajt ligger på Cloudflare Pages händer detta automatiskt. Besök `https://lyrik.dbts.se` i mobilen, klicka på webbläsarens meny och välj **Lägg till på hemskärmen**.

## 5. Uppdatera sajten

Varje gång du pushar nya filer till ditt GitHub‑repo körs en ny build och din sajt uppdateras. Behöver du till exempel lägga till fler rader i banken eller ändra kod, gör ändringen lokalt, commit:a och pusha.

## Felsökning

Om något inte fungerar:

- Kontrollera att du verkligen har laddat upp filerna i rätt repo.
- Cloudflare Pages måste kunna hitta `index.html` i roten – inga undersidor.
- Se till att subdomänen har propag­erat (kan ta upp till en timme). Testa `dig lyrik.dbts.se` i terminalen.

Nu är du redo att dela din LyrikOS med världen!