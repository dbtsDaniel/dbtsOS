/* app.js
 *
 * Detta är huvudlogiken för LyrikOS. Den hanterar navigering mellan vyer,
 * CRUD-operationer för värld → profil → album → spår, samt generering av
 * prompts och Suno-export. Koden är avsiktligt enkel för att en 13-åring
 * ska kunna följa flödet och experimentera.
 */

import DB from './db.js';
import { seedDatabase, defaultThemes, defaultRows } from './seeds.js';

const db = new DB();

// Global state
let currentWorld = null;
let currentProfile = null;
let currentAlbum = null;
let currentTrack = null;

// DOM references
const viewContainer = document.getElementById('view-container');

async function init() {
  try {
    await db.init();
    await seedDatabase(db);
    // Attach event listeners on nav buttons
    document.querySelectorAll('nav button').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.getAttribute('data-view');
        renderView(view);
      });
    });
    // Render home by default
    renderView('home');
  } catch (err) {
    console.error('Init error:', err);
    // Visa fel i UI om något går snett
    if (viewContainer) {
      viewContainer.innerHTML = `<p style="color: #f88;">Fel vid init: ${err.message || err}</p>`;
    }
  }
}

// Kör init när DOM laddas. Detta behövs eftersom index.html inte explicit anropar
// init(), och utan detta sker ingen uppsättning av event handlers eller rendering.
// Kör init direkt när modulen laddas. När sidan laddas via file:// är
// DOMContentLoaded redan klar, så vi anropar init på en gång. Fel
// loggas till konsolen om något går fel.
init().catch(err => console.error('Fel vid init:', err));

function renderView(view) {
  viewContainer.innerHTML = '';
  switch (view) {
    case 'home':
      renderHome();
      break;
    case 'bank':
      renderBank();
      break;
    case 'wizard':
      renderWizard();
      break;
    case 'suno':
      renderSuno();
      break;
    case 'vault':
      renderVault();
      break;
    case 'settings':
      renderSettings();
      break;
    default:
      renderHome();
  }
}

// ------------------------ Home ------------------------
async function renderHome() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Hem / Hierarki</h2>
    <p>Här skapar du din värld, profil, album och spår i ordning. Dessa sparas lokalt.</p>
    <div class="form-group">
      <label for="world-name">1. Skapa eller välj Värld</label>
      <input id="world-name" placeholder="Namn på värld" />
      <button id="create-world">Spara värld</button>
      <div id="world-list"></div>
    </div>
    <div class="form-group">
      <label for="profile-name">2. Skapa eller välj Profil</label>
      <input id="profile-name" placeholder="Artist/profil" />
      <button id="create-profile">Spara profil</button>
      <div id="profile-list"></div>
    </div>
    <div class="form-group">
      <label for="album-name">3. Skapa eller välj Album</label>
      <input id="album-name" placeholder="Album" />
      <button id="create-album">Spara album</button>
      <div id="album-list"></div>
    </div>
    <div class="form-group">
      <label for="track-name">4. Skapa eller välj Spår</label>
      <input id="track-name" placeholder="Spår" />
      <button id="create-track">Spara spår</button>
      <div id="track-list"></div>
    </div>
    <div class="form-group">
      <button id="continue-wizard" disabled>Fortsätt till wizard</button>
    </div>
  `;
  viewContainer.appendChild(section);
  // Load lists
  await populateHierarchyLists(section);
  // Event handlers
  section.querySelector('#create-world').addEventListener('click', async () => {
    const name = section.querySelector('#world-name').value.trim();
    if (!name) return;
    const id = await db.add('worlds', { name });
    currentWorld = { id, name };
    await populateHierarchyLists(section);
  });
  section.querySelector('#create-profile').addEventListener('click', async () => {
    if (!currentWorld) { alert('Välj först en värld.'); return; }
    const name = section.querySelector('#profile-name').value.trim();
    if (!name) return;
    const id = await db.add('profiles', { name, worldId: currentWorld.id });
    currentProfile = { id, name, worldId: currentWorld.id };
    await populateHierarchyLists(section);
  });
  section.querySelector('#create-album').addEventListener('click', async () => {
    if (!currentProfile) { alert('Välj först en profil.'); return; }
    const name = section.querySelector('#album-name').value.trim();
    if (!name) return;
    const id = await db.add('albums', { name, profileId: currentProfile.id });
    currentAlbum = { id, name, profileId: currentProfile.id };
    await populateHierarchyLists(section);
  });
  section.querySelector('#create-track').addEventListener('click', async () => {
    if (!currentAlbum) { alert('Välj först ett album.'); return; }
    const name = section.querySelector('#track-name').value.trim();
    if (!name) return;
    const id = await db.add('tracks', { name, albumId: currentAlbum.id });
    currentTrack = { id, name, albumId: currentAlbum.id };
    await populateHierarchyLists(section);
  });
  section.querySelector('#continue-wizard').addEventListener('click', () => {
    renderView('wizard');
  });
}

async function populateHierarchyLists(section) {
  const worldList = section.querySelector('#world-list');
  const worlds = await db.getAll('worlds');
  worldList.innerHTML = worlds.map(w => `<button class="hierarchy-item" data-type="world" data-id="${w.id}">${w.name}</button>`).join(' ');
  worldList.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentWorld = worlds.find(w => w.id === id);
      currentProfile = null;
      currentAlbum = null;
      currentTrack = null;
      await populateHierarchyLists(section);
    });
  });
  const profileList = section.querySelector('#profile-list');
  let profiles = [];
  if (currentWorld) {
    const allProfiles = await db.getAll('profiles');
    profiles = allProfiles.filter(p => p.worldId === currentWorld.id);
  }
  profileList.innerHTML = profiles.map(p => `<button data-type="profile" data-id="${p.id}">${p.name}</button>`).join(' ');
  profileList.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentProfile = profiles.find(p => p.id === id);
      currentAlbum = null;
      currentTrack = null;
      await populateHierarchyLists(section);
    });
  });
  const albumList = section.querySelector('#album-list');
  let albums = [];
  if (currentProfile) {
    const allAlbums = await db.getAll('albums');
    albums = allAlbums.filter(a => a.profileId === currentProfile.id);
  }
  albumList.innerHTML = albums.map(a => `<button data-type="album" data-id="${a.id}">${a.name}</button>`).join(' ');
  albumList.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentAlbum = albums.find(a => a.id === id);
      currentTrack = null;
      await populateHierarchyLists(section);
    });
  });
  const trackList = section.querySelector('#track-list');
  let tracks = [];
  if (currentAlbum) {
    const allTracks = await db.getAll('tracks');
    tracks = allTracks.filter(t => t.albumId === currentAlbum.id);
  }
  trackList.innerHTML = tracks.map(t => `<button data-type="track" data-id="${t.id}">${t.name}</button>`).join(' ');
  trackList.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentTrack = tracks.find(t => t.id === id);
      await populateHierarchyLists(section);
    });
  });
  // Enable continue if track selected
  const contBtn = section.querySelector('#continue-wizard');
  contBtn.disabled = !(currentWorld && currentProfile && currentAlbum && currentTrack);
}

// ------------------------ Bank ------------------------
async function renderBank() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Bank: Rader & Rim</h2>
    <p>Här kan du söka i den lokala bankens rader, importera och exportera CSV.</p>
    <div class="form-group">
      <label for="theme-filter">Filtrera på tema</label>
      <select id="theme-filter"></select>
      <button id="filter-lines">Filtrera</button>
    </div>
    <div id="bank-table"></div>
    <div class="form-group">
      <label for="csv-file">Importera CSV med kolumner: id,text,type,themes,rewrite1,rewrite2,rewrite3,rewrite4</label>
      <input type="file" id="csv-file" accept=".csv" />
      <button id="import-csv">Importera</button>
    </div>
    <div class="form-group">
      <button id="export-csv">Exportera CSV (alla rader)</button>
    </div>
  `;
  viewContainer.appendChild(section);
  // Populate theme filter
  const themes = await db.getAll('themes');
  const select = section.querySelector('#theme-filter');
  select.innerHTML = '<option value="">– Alla –</option>' + themes.map(t => `<option value="${t.name}">${t.name}</option>`).join('');
  // Load all lines initially
  await renderBankTable(section, null);
  section.querySelector('#filter-lines').addEventListener('click', async () => {
    const val = select.value;
    await renderBankTable(section, val || null);
  });
  section.querySelector('#import-csv').addEventListener('click', async () => {
    const fileInput = section.querySelector('#csv-file');
    if (!fileInput.files.length) return;
    const file = fileInput.files[0];
    const text = await file.text();
    const rows = text.trim().split(/\n+/);
    for (const row of rows.slice(1)) { // skip header
      const [id, base_text, type, themesStr, r1, r2, r3, r4] = row.split(',');
      const themesArr = themesStr ? themesStr.split('|').map(s => s.trim()) : [];
      await db.add('lines', { id: id || crypto.randomUUID(), base_text, type, themes: themesArr, rewrites: [r1, r2, r3, r4], ratings: { impact: 3, novelty: 3, singability: 3, clarity: 3 }, suno_notes: {} });
    }
    alert('Import klar');
    await renderBankTable(section, null);
  });
  section.querySelector('#export-csv').addEventListener('click', async () => {
    const lines = await db.getAll('lines');
    let csv = 'id,base_text,type,themes,rewrite1,rewrite2,rewrite3,rewrite4\n';
    for (const row of lines) {
      const themesJoined = row.themes ? row.themes.join('|') : '';
      csv += `${row.id},"${row.base_text.replace(/"/g,'""')}",${row.type},${themesJoined},"${row.rewrites[0]}","${row.rewrites[1]}","${row.rewrites[2]}","${row.rewrites[3]}"\n`;
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bank_export.csv';
    a.click();
    URL.revokeObjectURL(url);
  });
}

async function renderBankTable(section, themeFilter) {
  const container = section.querySelector('#bank-table');
  let lines;
  if (themeFilter) {
    lines = await db.queryLinesByTheme(themeFilter);
  } else {
    lines = await db.getAll('lines');
  }
  if (!lines.length) {
    container.innerHTML = '<p>Inga rader hittades.</p>';
    return;
  }
  let html = '<table><tr><th>ID</th><th>Text</th><th>Teman</th></tr>';
  for (const row of lines) {
    html += `<tr><td>${row.id}</td><td>${row.base_text}</td><td>${row.themes ? row.themes.join(', ') : ''}</td></tr>`;
  }
  html += '</table>';
  container.innerHTML = html;
}

// ------------------------ Wizard ------------------------
function renderWizard() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Wizard – 5 val</h2>
    <p>Varje steg i skapandet har fem alternativ. Du väljer ett för att fortsätta.</p>
    <div class="wizard-buttons">
      <button data-level="1">1. Snabb</button>
      <button data-level="2">2. Standard</button>
      <button data-level="3">3. Djup</button>
      <button data-level="4">4. Experiment</button>
      <button data-level="5">5. Felsök</button>
    </div>
    <div id="prompt-output">
      <p>Välj ett alternativ för att generera en prompt.</p>
    </div>
  `;
  viewContainer.appendChild(section);
  section.querySelectorAll('.wizard-buttons button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const level = btn.dataset.level;
      const prompt = await generatePrompt(level);
      const output = section.querySelector('#prompt-output');
      output.innerHTML = `<textarea style="width:100%;height:180px;">${prompt}</textarea><br/><button id="copy-prompt">Kopiera prompt</button>`;
      output.querySelector('#copy-prompt').addEventListener('click', () => {
        const ta = output.querySelector('textarea');
        ta.select();
        document.execCommand('copy');
        alert('Prompt kopierad!');
      });
    });
  });
}

async function generatePrompt(level) {
  // Simple prompt generation using current selections and level names
  const levels = {
    '1': 'Snabb',
    '2': 'Standard',
    '3': 'Djup',
    '4': 'Experiment',
    '5': 'Felsök'
  };
  const levelName = levels[level] || 'Standard';
  const worldName = currentWorld ? currentWorld.name : 'okänd värld';
  const profileName = currentProfile ? currentProfile.name : 'okänd profil';
  const albumName = currentAlbum ? currentAlbum.name : 'okänt album';
  const trackName = currentTrack ? currentTrack.name : 'okänt spår';
  const prompt = `Du arbetar med värld "${worldName}", profil "${profileName}", album "${albumName}", spår "${trackName}".\n` +
    `Du har valt läge ${levelName}. Generera en låttextstruktur med lämpliga rim och metaforer från banken. Följ DBTS-reglerna för svensk melopoesi.\n` +
    `Steg efter detta: 1. Snabb 2. Standard 3. Djup 4. Experiment 5. Felsök`;
  return prompt;
}

// ------------------------ Suno ------------------------
function renderSuno() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Suno Export</h2>
    <p>Samla din låttext, stil och negativa prompt här och exportera till Suno PRO v5.</p>
    <div class="form-group">
      <label for="lyrics-area">Lyrics (sektioner i block med [VERSE], [HOOK], [BRIDGE])</label>
      <textarea id="lyrics-area" rows="8" placeholder="[VERSE]\nDin text här..."></textarea>
    </div>
    <div class="form-group">
      <label for="style-input">Stilbeskrivning (engelska)</label>
      <input id="style-input" placeholder="Swedish vals-trap, 6/8, 74-80 BPM" />
    </div>
    <div class="form-group">
      <label for="exclude-input">Exclude (negativ prompt)</label>
      <input id="exclude-input" placeholder="Exclude: autotune, cliché, english" />
    </div>
    <div class="form-group">
      <label for="notes-input">Metadata/Persona/Reuse hints</label>
      <input id="notes-input" placeholder="Persona: ...; Reuse Prompt: yes" />
    </div>
    <button id="generate-suno">Generera Suno-paket</button>
    <div id="suno-output"></div>
  `;
  viewContainer.appendChild(section);
  section.querySelector('#generate-suno').addEventListener('click', () => {
    const lyrics = section.querySelector('#lyrics-area').value.trim();
    const style = section.querySelector('#style-input').value.trim();
    const exclude = section.querySelector('#exclude-input').value.trim();
    const notes = section.querySelector('#notes-input').value.trim();
    const pkg = `Lyrics:\n${lyrics}\n\nStyle: ${style}\nExclude: ${exclude}\nNotes: ${notes}`;
    const out = section.querySelector('#suno-output');
    out.innerHTML = `<textarea style="width:100%;height:200px;">${pkg}</textarea><br/><button id="copy-suno">Kopiera</button>`;
    out.querySelector('#copy-suno').addEventListener('click', () => {
      const ta = out.querySelector('textarea');
      ta.select();
      document.execCommand('copy');
      alert('Suno-paket kopierat!');
    });
  });
}

// ------------------------ Vault ------------------------
function renderVault() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Vault / Logg</h2>
    <p>Här kan du skriva anteckningar för spåret och spara snapshot. Funktionaliteten är minimal i denna MVP.</p>
    <div class="form-group">
      <label for="note-area">Anteckningar</label>
      <textarea id="note-area" rows="6" placeholder="Skriv dina tankar om detta spår..."></textarea>
    </div>
    <button id="save-note">Spara anteckning</button>
    <div id="vault-list"></div>
  `;
  viewContainer.appendChild(section);
  loadVaultList(section);
  section.querySelector('#save-note').addEventListener('click', async () => {
    if (!currentTrack) { alert('Välj ett spår under Hem.'); return; }
    const note = section.querySelector('#note-area').value.trim();
    if (!note) return;
    await db.add('vault', { trackId: currentTrack.id, note, timestamp: Date.now() });
    section.querySelector('#note-area').value = '';
    loadVaultList(section);
  });
}

async function loadVaultList(section) {
  const list = section.querySelector('#vault-list');
  if (!currentTrack) {
    list.innerHTML = '<p>Inga anteckningar – välj spår under Hem.</p>';
    return;
  }
  const allNotes = await db.getAll('vault');
  const notes = allNotes.filter(n => n.trackId === currentTrack.id).sort((a,b) => b.timestamp - a.timestamp).slice(0,10);
  if (!notes.length) {
    list.innerHTML = '<p>Inga anteckningar sparade för detta spår.</p>';
    return;
  }
  let html = '<ul>';
  for (const n of notes) {
    const date = new Date(n.timestamp).toLocaleString();
    html += `<li><strong>${date}</strong>: ${n.note}</li>`;
  }
  html += '</ul>';
  list.innerHTML = html;
}

// ------------------------ Settings ------------------------
function renderSettings() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Inställningar & Backup</h2>
    <p>Spara och importera hela databasen som JSON. Notera att export/import skriver över nuvarande data.</p>
    <button id="export-json">Exportera JSON</button>
    <div class="form-group">
      <label for="json-file">Importera JSON backup</label>
      <input type="file" id="json-file" accept=".json" />
      <button id="import-json">Importera</button>
    </div>
    <p>När du kör appen på en säker domän (https) kan du aktivera persistent lagring för att minska risken att webbläsaren rensar datat. Denna funktion kräver ett säkert ursprung.</p>
    <button id="request-persist">Begär persistent lagring</button>
    <div id="storage-status"></div>
  `;
  viewContainer.appendChild(section);
  section.querySelector('#export-json').addEventListener('click', async () => {
    const stores = ['worlds','profiles','albums','tracks','lines','themes','vault'];
    const exportData = {};
    for (const store of stores) {
      exportData[store] = await db.getAll(store);
    }
    const blob = new Blob([JSON.stringify(exportData)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'lyrikos_backup.json';
    a.click();
    URL.revokeObjectURL(url);
  });
  section.querySelector('#import-json').addEventListener('click', async () => {
    const fileInput = section.querySelector('#json-file');
    if (!fileInput.files.length) return;
    const file = fileInput.files[0];
    const text = await file.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      alert('Filen är inte giltig JSON.'); return;
    }
    // Clear and import
    const dbConn = await db.init();
    const tx = dbConn.transaction(['worlds','profiles','albums','tracks','lines','themes','vault'], 'readwrite');
    for (const storeName of ['worlds','profiles','albums','tracks','lines','themes','vault']) {
      const store = tx.objectStore(storeName);
      await store.clear();
      if (Array.isArray(data[storeName])) {
        for (const entry of data[storeName]) {
          store.put(entry);
        }
      }
    }
    tx.oncomplete = () => {
      alert('Import klar!');
    };
  });
  section.querySelector('#request-persist').addEventListener('click', async () => {
    if (navigator.storage && navigator.storage.persist) {
      const granted = await navigator.storage.persist();
      section.querySelector('#storage-status').textContent = granted ? 'Persistent lagring aktiverad.' : 'Kunde inte aktivera persistent lagring.';
    } else {
      section.querySelector('#storage-status').textContent = 'Persistent storage stöds inte i denna webbläsare.';
    }
  });
}

// Kick off the app
window.addEventListener('DOMContentLoaded', init);