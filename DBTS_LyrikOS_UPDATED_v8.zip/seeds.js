/*
 * seeds.js
 *
 * Detta skript innehåller startdata för teman och rader. När appen laddas första
 * gången injiceras dessa rader och teman i IndexedDB om de inte redan finns.
 */

export const defaultThemes = [
  'Tid',
  'Digital Friktion',
  'BankID',
  'Systemiska Absurdities',
  'Samtidsrealism',
  'Kontroll',
  'Nostalgi',
  'Arv',
  'Tidens Fängelse',
  'Politik',
  'Ekonomi',
  'Samvetskval',
  'Teknologiskt Lidande',
  'Paradox',
  'Kreativitet',
  'Prosodi',
  'Melopoesi',
  'Systemkritik',
  'Sociala medier',
  'Byråkrati'
];

export const defaultRows = [
  {
    id: 'D-01',
    base_text: 'Och du klickade på "Glömt lösenord", och systemet sade: "Det nya lösenordet får inte vara samma som det gamla", vilket bevisade att de visste ditt lösenord men vägrade släppa in dig.',
    type: 'paradox',
    themes: ['Digital Friktion','Systemiska Absurdities'],
    rewrites: [
      'När du försöker ändra ditt lösenord, men systemet avfärdar din nya idé eftersom den matchar den gamla – en påminnelse om att någon redan vet din kod men ändå låser dörren.',
      'Du begär återställning av lösenord och får svaret: det nya får inte vara det gamla, som om tjänsten redan känner dig men vägrar släppa in dig.',
      'Systemet säger åt dig att inte använda ditt gamla lösenord, trots att det uppenbarligen redan känner till det – en administrativ paradox.',
      'Paradoxen när du klickar "glömt lösenord" och får veta att ditt nya ord inte får vara samma som det gamla, trots att någon redan har ditt gamla.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  // Startkit från Anti-Bibeln och Svenska markörer
  {
    id: 'SB-01',
    base_text: 'Svettiga händer på plastmapp, väntetid 47 minuter',
    type: 'metafor',
    themes: ['Stress','Väntan'],
    rewrites: [
      'Det kladdar om mina händer på plastmappen medan jag räknar minut 47',
      'Handflatan glider över plasten, könumret blinkar 47',
      'Jag torkar bort svetten på plastfickan, 47 siffror kvar',
      'Lappar plast, svettpärlor och väntetid – fyrtiosju slag'
    ],
    ratings: { impact: 4, novelty: 5, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'SB-02',
    base_text: 'BankID‑popup kliver in under tårkanterna',
    type: 'metafor',
    themes: ['System','Gråt'],
    rewrites: [
      'BankID‑rutan blinkar mitt i gråten',
      'BankID‑ljuset tänder tårkanalen',
      'Systempopupen skaver i ögonvrån',
      'BankID‑signal möter fuktig kind'
    ],
    ratings: { impact: 3, novelty: 4, singability: 4, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'SB-03',
    base_text: 'Nattöppet snabbköp, lysrörsbrus i ensamma öron',
    type: 'scen',
    themes: ['Ensamhet','Stad'],
    rewrites: [
      'Midnattshallen sjunger med lysrören runt mig',
      'Nattkassan blinkar kallt och surrar i huvudet',
      'Jag vandrar mellan hyllor medan lampor brusar',
      'Lysrören viskar i mina öron i den öppna natten'
    ],
    ratings: { impact: 4, novelty: 4, singability: 3, clarity: 5 },
    suno_notes: {}
  },
  {
    id: 'SB-04',
    base_text: 'Kivra‑notis 21:45, helgen knäcks i kantlinjer',
    type: 'metafor',
    themes: ['System','Helg'],
    rewrites: [
      'Kivra plingar kvart i tio och bryter fredagslugnet',
      'Digital brevlåda slår ner på min helg',
      'Kivranotisen skär i kvällens mjukhet',
      'En fredagsnatt bryts av ett systempip'
    ],
    ratings: { impact: 3, novelty: 5, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'SB-05',
    base_text: 'Portkodsklick i tyst trapphus, hjärtat hackar i takt',
    type: 'scen',
    themes: ['Vardag','Stress'],
    rewrites: [
      'Mina fingrar knappar koden medan pulsen ökar',
      'Portkoden piper och hjärtat hoppar med',
      'Knastret från siffrorna följs av mina hjärtslag',
      'Koden klickar, bröstet knackar'
    ],
    ratings: { impact: 4, novelty: 4, singability: 4, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'SB-06',
    base_text: 'Skrynkligt ICA‑kvitto, minus i banken, plus i bröstet',
    type: 'metafor',
    themes: ['Ekonomi','Kropp'],
    rewrites: [
      'Ett skrynkligt kvitto säger minus men bröstet säger plus',
      'Kvittot krullar sig, kontot är rött men jag är hel',
      'Ekonomin blöder medan mitt bröst slår starkt',
      'Minus på pappret, plus i kroppen'
    ],
    ratings: { impact: 5, novelty: 5, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'SB-07',
    base_text: 'Barnlås på skåp och tankar, impulser låses in',
    type: 'metafor',
    themes: ['Säkerhet','Kaos'],
    rewrites: [
      'Lås på lådor och i huvudet, spärrar känslan',
      'Barnlåset klickar på tankarna så de inte rusar',
      'Jag sätter spärrar på skåp och idéer',
      'Säkra skåp, säkrade impulser'
    ],
    ratings: { impact: 4, novelty: 3, singability: 4, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'SB-08',
    base_text: 'Diskmaskinens avslutande sus som symfoni för ensam',
    type: 'scen',
    themes: ['Ensamhet','Vardag'],
    rewrites: [
      'Det sista suget från diskmaskinen är min lullaby',
      'Diskmaskinens suck är dagens sista låt',
      'Suset från maskinen fyller lägenheten som en orkester',
      'Maskinen tystnar och tystnad tar över'
    ],
    ratings: { impact: 4, novelty: 4, singability: 3, clarity: 5 },
    suno_notes: {}
  },
  {
    id: 'SB-09',
    base_text: 'Teams‑pling ekar i märgen, livet i autopilot',
    type: 'metafor',
    themes: ['Arbete','Stress'],
    rewrites: [
      'Ett Teamspling går rakt i benmärgen, digitalt påslag',
      'Datamötet pingar, jag följer utan att tänka',
      'Plinget i hörlurarna styr min rytm',
      'Autopiloten startar när plinget låter'
    ],
    ratings: { impact: 4, novelty: 3, singability: 4, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'SB-10',
    base_text: 'Vinylknaster och hissbrus, ansiktets mask',
    type: 'scen',
    themes: ['Nostalgi','Isolation'],
    rewrites: [
      'Skivknastret blandas med hissljusets brus',
      'Hissen surrar och vinylen knastrar i bakgrunden',
      'Nålen hoppar, hissen sjunger, ansiktet är stilla',
      'Bakgrundsljuden bär min mask'
    ],
    ratings: { impact: 3, novelty: 4, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-02',
    base_text: 'Saliga äro de som inte har BankID på fil, ty de skola ärva en administrativ skärseld utan slut.',
    type: 'metafor',
    themes: ['BankID','Byråkrati'],
    rewrites: [
      'Lyckliga de utan BankID, ty de får ägna evigheten åt administrativt limbo.',
      'Välsignade de som saknar BankID – de får uppleva byråkratins skärseld utan ände.',
      'Den som ej har BankID på fil är dömd till ändlös digital prövning.',
      'Den som saknar BankID möter en oändlig administrativ brasa.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 2, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-03',
    base_text: 'En notis från Kivra klockan 21:45 på en fredag är inte post; det är en digital örfil.',
    type: 'punchline',
    themes: ['Digital Friktion','Temporal Kränkning'],
    rewrites: [
      'När Kivra plingar på fredagkväll känns det mer som en örfil än post.',
      'Ett Kivra-meddelande 21:45 är mer en chock än leverans.',
      'Kivra-notisen sent på kvällen är som ett slag i ansiktet, inte ett brev.',
      'När brevlådan pingar på fredagsnatten är det en örfil, inte post.'
    ],
    ratings: { impact: 4, novelty: 3, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-04',
    base_text: 'Du skall icke begå dråp, men du skall känna en mörk lust när 2FA-koden anländer tre sekunder efter att tidsfönstret löpt ut.',
    type: 'metafor',
    themes: ['Digital Friktion','Latens-Raseri'],
    rewrites: [
      'Du ska inte döda, men du kommer att koka när säkerhetskoden kommer för sent.',
      'Tvåfaktorkoden landar tre sekunder för sent och väcker mordiska impulser.',
      'Lagen säger nej till dråp, men en sen 2FA-kod väcker mörka lustar.',
      'När tidsfönstret stängt och koden droppar in, känner man raseri.'
    ],
    ratings: { impact: 4, novelty: 3, singability: 2, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-05',
    base_text: 'Ve den som försöker betala parkering i en zon där tre olika appar hävdar jurisdiktion, men ingen accepterar ditt kort.',
    type: 'metafor',
    themes: ['Infrastrukturell Fragmentering','Digital Friktion'],
    rewrites: [
      'Förbannelse över den som försöker betala parkeringen där tre appar tävlar men ingen fungerar.',
      'Att parkera där tre appar styr och ingen tar ditt kort är rena plågan.',
      'I zoner där tre appar kräver betalning men ingen accepterar dig faller förbannelsen.',
      'Parkera inte där tre appar delar makten men ingen tar betalt.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-06',
    base_text: 'Att behöva ladda ner en 150 MB app för att beställa en öl på en krog där du har ögonkontakt med bartendern.',
    type: 'metafor',
    themes: ['Interaktions-Redundans','Digital Friktion'],
    rewrites: [
      'Du laddar en tung app bara för att beställa öl medan du redan ser bartendern.',
      'Behovet av att hämta en gigantisk app för en enkel öl när bartendern står där.',
      'En 150 MB app för att be om en öl du redan kan be om med blicken.',
      'Att tanka ner en app större än din törst för att beställa en öl personligen.'
    ],
    ratings: { impact: 3, novelty: 4, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-07',
    base_text: '"Vi värnar om din integritet" sade popup-fönstret som täckte 90% av skärmen och krävde tre klick för att avvisa cookies.',
    type: 'punchline',
    themes: ['Hyckleriets Design','Digital Friktion'],
    rewrites: [
      'Integritets-popupen som skymmer allt och kräver tre klick för att försvinna.',
      'Ett fönster om integritet som tar över skärmen och tvingar dig att acceptera.',
      'När cookies-dialogen tar hela skärmen i namn av integritet.',
      '"Vi värnar om din integritet" medan du klickar dig igenom tre skärmar.'
    ],
    ratings: { impact: 4, novelty: 3, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-08',
    base_text: 'Den existentiella tomheten när internetbanken ligger nere för "planerat underhåll" exakt den minut du ska betala hyran.',
    type: 'metafor',
    themes: ['Systemiskt Sve','Ekonomi'],
    rewrites: [
      'Banken dör för underhåll just när hyran ska betalas – ett hån i realtid.',
      'När underhåll stoppar din bankapp i samma sekund som du ska betala hyran.',
      'Planerat underhåll i banken i exakt samma minut som hyran ska in: tomhet.',
      'Exakt när pengarna ska ut meddelar banken driftstopp.'
    ],
    ratings: { impact: 4, novelty: 3, singability: 2, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-09',
    base_text: 'Att skanna en QR-kod för menyn och mötas av en PDF som inte är mobilanpassad, så du måste scrolla i sidled för att se priset.',
    type: 'metafor',
    themes: ['UX-Sadism','Digital Friktion'],
    rewrites: [
      'Du skannar en kod och får en PDF att panorera i sidled för att hitta priset.',
      'En QR-kod leder till en omöjlig PDF-meny som kräver sidscroll för priser.',
      'När menyn är en oskön PDF på mobilen som kräver horisontell scroll.',
      'Scroll i sidled för att se priser efter att ha skannat en QR-meny.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-10',
    base_text: 'När autokorrekt ändrar ett korrekt, sällsynt ord till ett vanligt, felaktigt ord precis när du trycker "Skicka".',
    type: 'punchline',
    themes: ['Algoritmisk Arrogans','Digital Friktion'],
    rewrites: [
      'Autokorrekt förstör ditt ovanliga ord i samma sekund du skickar det.',
      'Du skriver ett unikt ord och autokorrigeringen gör det trivial precis vid sändning.',
      'Ett vackert ord blir saboterat av autocorrect när du trycker skicka.',
      'Autokorrekt ändrar ett korrekt ovanligt ord till fel precis på avtryckaren.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 3, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-11',
    base_text: 'Rädslan för att råka "Gilla" en bild från 2016 när du djupscrollar på någons Instagramprofil.',
    type: 'punchline',
    themes: ['Social Gruvdrift','Sociala medier'],
    rewrites: [
      'Du djupscrollar och fruktar att gilla ett gammalt foto från 2016.',
      'Paniken att dubbeltappa fel år på någons profil.',
      'Rädslan att gilla en bild djupt ned i flödet och avslöja dig.',
      'När du scrollar långt bak och varenda like känns som en bekännelse.'
    ],
    ratings: { impact: 3, novelty: 4, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-12',
    base_text: 'Att behöva skapa ett konto med versal, siffra och specialtecken för att köpa engångsstrumpor.',
    type: 'punchline',
    themes: ['Säkerhets-Teater','Digital Friktion'],
    rewrites: [
      'Du måste skapa ett superkomplext konto bara för att köpa strumpor.',
      'Ett lösenord med allt – bara för engångsstrumpor.',
      'Konto med versaler, siffror och symboler för en trivial beställning.',
      'Du designar ett hacker-säkert lösenord för att köpa ett par strumpor.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 2, clarity: 4 },
    suno_notes: {}
  },
  {
    id: 'D-13',
    base_text: 'Du skall hedra din fader och moder, men du skall icke vara deras IT-support när de raderat ikonen för "Internet".',
    type: 'punchline',
    themes: ['Generations-Bördan','Byråkrati'],
    rewrites: [
      'Ära dina föräldrar men var inte deras IT-avdelning när de raderar webbläsaren.',
      'Du ska hedra dem men inte vara support när de tar bort internetikonen.',
      'Hedra föräldrarna, men nej, du är inte deras IT-support.',
      'När mamma tar bort internetikonen och du måste rädda henne igen.'
    ],
    ratings: { impact: 3, novelty: 4, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-14',
    base_text: 'När Spotify spelar en podcast du aldrig valt bara för att algoritmen tror att du gillar "True Crime om skattebrott".',
    type: 'punchline',
    themes: ['Profilerings-Fel','Digital Friktion'],
    rewrites: [
      'Musiktjänsten spelar en random podd för att algoritmen tror den känner dig.',
      'Spotify startar en obskyr true crime om skatter utan ditt medgivande.',
      'Algoritmen matar dig med en podd du aldrig bett om om skattebrott.',
      'När rekommendationsmotorn tycker du vill höra true crime om skatt.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-15',
    base_text: 'Att försöka avsluta en prenumeration där "Avsluta"-knappen är grå på grå bakgrund och gömd under "Inställningar > Konto > Övrigt > Juridik".',
    type: 'metafor',
    themes: ['Mörka Mönster','Digital Friktion'],
    rewrites: [
      'Att säga upp en tjänst där knappen är gömd och osynlig.',
      'Uppsägning gömd i menyn under juridik, grå text på grå bakgrund.',
      'När avsluta-knappen är en labyrint av inställningar och grått mot grått.',
      'Mörka designmönster gör prenumerationsavslut till en skattjakt.'
    ],
    ratings: { impact: 4, novelty: 3, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-16',
    base_text: 'Den tysta paniken när batteriet visar 1% och din tågbiljett ligger i appen.',
    type: 'punchline',
    themes: ['Digital Sårbarhet','Ekonomi'],
    rewrites: [
      'Du ser 1 % batteri och din biljett finns bara i en app.',
      'Den dova paniken när mobilen nästan dör och tågbiljetten är digital.',
      'Batteriet blinkar rött medan din biljett sover i appen.',
      '1 % batteri och biljetten digital – pulsen stiger.'
    ],
    ratings: { impact: 4, novelty: 3, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-17',
    base_text: 'När du måste verifiera att du "inte är en robot" genom att identifiera trafikljus, och du misslyckas för att en pixel av stolpen var i fel ruta.',
    type: 'punchline',
    themes: ['Turing-Förnedring','Digital Friktion'],
    rewrites: [
      'Du får bevisa att du inte är en robot genom att klicka trafikljus, och misslyckas på en pixel.',
      'CAPTCHA-testet fäller dig för att stolpen sträckte sig in i nästa ruta.',
      'När du fastnar i en robotkontroll för att ett trafikljus spiller över sin ruta.',
      'Robottestet där en enda pixel gör dig omänsklig.'
    ],
    ratings: { impact: 3, novelty: 4, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-18',
    base_text: 'Att få ett mejl med ämnesraden "Viktig information om ditt konto" som visar sig vara reklam för en tilläggsförsäkring.',
    type: 'punchline',
    themes: ['Uppmärksamhets-Stöld','Byråkrati'],
    rewrites: [
      'Mejlet lovar viktig kontoinformation men säljer dig försäkringar.',
      'Ämnesraden skriker “viktigt” men innehållet är reklam.',
      'Du öppnar ett larmande mejl som visar sig vara en tilläggsförsäkring.',
      'Falsk alarm: kontomejl som egentligen är reklam.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 2, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-19',
    base_text: 'När din smarta dörrklocka kräver en prenumeration för att visa vem som ringer på dörren.',
    type: 'punchline',
    themes: ['Mikrotransaktions-Hemmet','Digital Friktion'],
    rewrites: [
      'Din dörrklocka vill ha prenumeration för att visa ansiktet på gästen.',
      'Smarta klockan tar betalt för att låta dig se vem som knackar.',
      'Du måste prenumerera på din egen dörrklockas bildflöde.',
      'Hemmet kräver mikrobetalning för att öppna dörren.'
    ],
    ratings: { impact: 3, novelty: 4, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  {
    id: 'D-20',
    base_text: 'Du skall icke stjäla, men du skall överväga piratkopiering när streamingtjänsten du betalar för tar bort din favoritserie.',
    type: 'metafor',
    themes: ['Licens-Godtycke','Digital Friktion'],
    rewrites: [
      'Streamingtjänsten tar bort din show och du funderar på att piratkopiera.',
      'Tjänsten du betalar för raderar serien och frestar dig att ladda ner.',
      'Du betalar, men serien försvinner och du lockas av piratbukten.',
      'När streamingtjänsten gömmer din favorit överväger du fildelning.'
    ],
    ratings: { impact: 3, novelty: 4, singability: 3, clarity: 3 },
    suno_notes: {}
  }
];

// Utility to load seeds if not present (called in app.js)
export async function seedDatabase(db) {
  const worldCount = await db.count('themes');
  if (worldCount === 0) {
    // insert themes
    for (const theme of defaultThemes) {
      await db.add('themes', { name: theme });
    }
  }
  const rowCount = await db.count('lines');
  if (rowCount === 0) {
    for (const row of defaultRows) {
      await db.add('lines', row);
    }
  }
}