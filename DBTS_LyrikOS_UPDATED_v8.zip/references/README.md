# Referenser

Den här mappen listar några av de originaldokument som detta projekt bygger på. Av upphovsrätts- och storleksskäl inkluderas inte hela innehållet här i zip-paketet. Du hittar originalfilerna i chatten där LyrikOS-projektet skapades.

- **Sverige-i-Tiden (4).md** – Fenomenologin av friktion och digitala anti-bibeln med 100+ exempel på svensk vardagsfrustration.
- **DBTS Master Priming_ Samladchatt.md** – Sammanfattning av DBTS-ramverkets filosofi, anti-bibeln och låtskrivarguide.
- **DBTS Master – SAMLING AV ALLT I EN FIL.md** – Ett längre dokument med kontextpaket, rimbank och scener.
- **Kreativa Bibeln.md** – Idébank för albumet “Kreativa Bibeln” med olika tolkningar av temat tid.
- **dbts_webbprojekt_oversikt.md** – Översikt över domänstruktur och hostingsförslag för dbts.se, .me, .pro och .shop.

Använd dessa dokument som inspiration när du fyller på banken med fler rader och teman. De ger kontext, exempel och idéer för prosodi, rim och tematisk riktning.