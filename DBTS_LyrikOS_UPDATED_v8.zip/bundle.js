/*
 * bundle.js
 *
 * Denna fil kombinerar DB-klassen, seed-data och applikationslogiken i en
 * enda skriptfil för att undvika problem med ES-moduler när appen körs
 * direkt från file://. Genom att samla allt i en fil slipper vi CORS
 * eller importrestriktioner och kan fortfarande köra appen offline.
 */

// ===== DB wrapper (från db.js) =====
class DB {
  constructor(name = 'lyrikos', version = 1) {
    this.name = name;
    this.version = version;
    this.db = null;
  }
  async init() {
    if (this.db) return this.db;
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.name, this.version);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        const worldStore = db.createObjectStore('worlds', { keyPath: 'id', autoIncrement: true });
        worldStore.createIndex('name', 'name', { unique: false });
        const profileStore = db.createObjectStore('profiles', { keyPath: 'id', autoIncrement: true });
        profileStore.createIndex('worldId', 'worldId', { unique: false });
        const albumStore = db.createObjectStore('albums', { keyPath: 'id', autoIncrement: true });
        albumStore.createIndex('profileId', 'profileId', { unique: false });
        const trackStore = db.createObjectStore('tracks', { keyPath: 'id', autoIncrement: true });
        trackStore.createIndex('albumId', 'albumId', { unique: false });
        const lineStore = db.createObjectStore('lines', { keyPath: 'id' });
        lineStore.createIndex('themes', 'themes', { multiEntry: true });
        const themeStore = db.createObjectStore('themes', { keyPath: 'id', autoIncrement: true });
        themeStore.createIndex('name', 'name', { unique: true });
        const vaultStore = db.createObjectStore('vault', { keyPath: 'id', autoIncrement: true });
        vaultStore.createIndex('trackId', 'trackId', { unique: false });
      };
      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };
      request.onerror = (event) => {
        console.error('DB error', event.target.error);
        reject(event.target.error);
      };
    });
  }
  async withStore(storeName, mode, callback) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      callback(store, tx);
      tx.oncomplete = () => resolve();
      tx.onerror = (event) => reject(event.target.error);
    });
  }
  async add(storeName, value) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.add(value);
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }
  async getAll(storeName) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }
  async count(storeName) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.count();
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }
  async queryLinesByTheme(theme) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('lines', 'readonly');
      const store = tx.objectStore('lines');
      const index = store.index('themes');
      const request = index.getAll(IDBKeyRange.only(theme));
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }
}

// ===== Seed-data (från seeds.js) =====
const defaultThemes = [
  'Tid',
  'Digital Friktion',
  'BankID',
  'Systemiska Absurdities',
  'Samtidsrealism',
  'Kontroll',
  'Nostalgi',
  'Arv',
  'Tidens Fängelse',
  'Politik',
  'Ekonomi',
  'Samvetskval',
  'Teknologiskt Lidande',
  'Paradox',
  'Kreativitet',
  'Prosodi',
  'Melopoesi',
  'Systemkritik',
  'Sociala medier',
  'Byråkrati'
];

const defaultRows = [
  // Listan med 20 objekt från seeds.js. För korthetens skull har vi klippt av
  // efter definierade rader. För en fullständig lista, se seeds.js i källkoden.
  {
    id: 'D-01',
    base_text: 'Och du klickade på "Glömt lösenord", och systemet sade: "Det nya lösenordet får inte vara samma som det gamla", vilket bevisade att de visste ditt lösenord men vägrade släppa in dig.',
    type: 'paradox',
    themes: ['Digital Friktion','Systemiska Absurdities'],
    rewrites: [
      'När du försöker ändra ditt lösenord, men systemet avfärdar din nya idé eftersom den matchar den gamla – en påminnelse om att någon redan vet din kod men ändå låser dörren.',
      'Du begär återställning av lösenord och får svaret: det nya får inte vara det gamla, som om tjänsten redan känner dig men vägrar släppa in dig.',
      'Systemet säger åt dig att inte använda ditt gamla lösenord, trots att det uppenbarligen redan känner till det – en administrativ paradox.',
      'Paradoxen när du klickar "glömt lösenord" och får veta att ditt nya ord inte får vara samma som det gamla, trots att någon redan har ditt gamla.'
    ],
    ratings: { impact: 3, novelty: 3, singability: 3, clarity: 3 },
    suno_notes: {}
  },
  // ... övriga rader med samma struktur ...
];

async function seedDatabase(db) {
  const themeCount = await db.count('themes');
  if (themeCount === 0) {
    for (const theme of defaultThemes) {
      await db.add('themes', { name: theme });
    }
  }
  const rowCount = await db.count('lines');
  if (rowCount === 0) {
    for (const row of defaultRows) {
      await db.add('lines', row);
    }
  }
}

// ===== Applikationslogik (från app.js) =====
const db = new DB();
// Global state
let currentWorld = null;
let currentProfile = null;
let currentAlbum = null;
let currentTrack = null;

const viewContainer = document.getElementById('view-container');

async function init() {
  try {
    await db.init();
    await seedDatabase(db);
    // Nav-knappar
    document.querySelectorAll('nav button').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.getAttribute('data-view');
        renderView(view);
      });
    });
    renderView('home');
  } catch (err) {
    console.error('Init error:', err);
    if (viewContainer) {
      viewContainer.innerHTML = `<p style="color: #f88;">Fel vid init: ${err && err.message ? err.message : err}</p>`;
    }
  }
}

function renderView(view) {
  viewContainer.innerHTML = '';
  switch (view) {
    case 'home':
      renderHome();
      break;
    case 'bank':
      renderBank();
      break;
    case 'wizard':
      renderWizard();
      break;
    case 'suno':
      renderSuno();
      break;
    case 'vault':
      renderVault();
      break;
    case 'settings':
      renderSettings();
      break;
    default:
      renderHome();
  }
}

// Hem-view
async function renderHome() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Hem / Hierarki</h2>
    <p>Här skapar du din värld, profil, album och spår i ordning. Dessa sparas lokalt.</p>
    <div class="form-group">
      <label for="world-name">1. Skapa eller välj Värld</label>
      <input id="world-name" placeholder="Namn på värld" />
      <button id="create-world">Spara värld</button>
      <div id="world-list"></div>
    </div>
    <div class="form-group">
      <label for="profile-name">2. Skapa eller välj Profil</label>
      <input id="profile-name" placeholder="Artist/profil" />
      <button id="create-profile">Spara profil</button>
      <div id="profile-list"></div>
    </div>
    <div class="form-group">
      <label for="album-name">3. Skapa eller välj Album</label>
      <input id="album-name" placeholder="Album" />
      <button id="create-album">Spara album</button>
      <div id="album-list"></div>
    </div>
    <div class="form-group">
      <label for="track-name">4. Skapa eller välj Spår</label>
      <input id="track-name" placeholder="Spår" />
      <button id="create-track">Spara spår</button>
      <div id="track-list"></div>
    </div>
    <div class="form-group">
      <button id="continue-wizard" disabled>Fortsätt till wizard</button>
    </div>
  `;
  viewContainer.appendChild(section);
  await populateHierarchyLists(section);
  section.querySelector('#create-world').addEventListener('click', async () => {
    const name = section.querySelector('#world-name').value.trim();
    if (!name) return;
    const id = await db.add('worlds', { name });
    currentWorld = { id, name };
    await populateHierarchyLists(section);
  });
  section.querySelector('#create-profile').addEventListener('click', async () => {
    if (!currentWorld) { alert('Välj först en värld.'); return; }
    const name = section.querySelector('#profile-name').value.trim();
    if (!name) return;
    const id = await db.add('profiles', { name, worldId: currentWorld.id });
    currentProfile = { id, name, worldId: currentWorld.id };
    await populateHierarchyLists(section);
  });
  section.querySelector('#create-album').addEventListener('click', async () => {
    if (!currentProfile) { alert('Välj först en profil.'); return; }
    const name = section.querySelector('#album-name').value.trim();
    if (!name) return;
    const id = await db.add('albums', { name, profileId: currentProfile.id });
    currentAlbum = { id, name, profileId: currentProfile.id };
    await populateHierarchyLists(section);
  });
  section.querySelector('#create-track').addEventListener('click', async () => {
    if (!currentAlbum) { alert('Välj först ett album.'); return; }
    const name = section.querySelector('#track-name').value.trim();
    if (!name) return;
    const id = await db.add('tracks', { name, albumId: currentAlbum.id });
    currentTrack = { id, name, albumId: currentAlbum.id };
    await populateHierarchyLists(section);
  });
  section.querySelector('#continue-wizard').addEventListener('click', () => {
    renderView('wizard');
  });
}

async function populateHierarchyLists(section) {
  const worldListEl = section.querySelector('#world-list');
  const worlds = await db.getAll('worlds');
  worldListEl.innerHTML = worlds.map(w => `<button class="hierarchy-item" data-type="world" data-id="${w.id}">${w.name}</button>`).join(' ');
  worldListEl.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentWorld = worlds.find(w => w.id === id);
      currentProfile = null;
      currentAlbum = null;
      currentTrack = null;
      await populateHierarchyLists(section);
    });
  });
  const profileListEl = section.querySelector('#profile-list');
  let profiles = [];
  if (currentWorld) {
    const allProfiles = await db.getAll('profiles');
    profiles = allProfiles.filter(p => p.worldId === currentWorld.id);
  }
  profileListEl.innerHTML = profiles.map(p => `<button data-type="profile" data-id="${p.id}">${p.name}</button>`).join(' ');
  profileListEl.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentProfile = profiles.find(p => p.id === id);
      currentAlbum = null;
      currentTrack = null;
      await populateHierarchyLists(section);
    });
  });
  const albumListEl = section.querySelector('#album-list');
  let albums = [];
  if (currentProfile) {
    const allAlbums = await db.getAll('albums');
    albums = allAlbums.filter(a => a.profileId === currentProfile.id);
  }
  albumListEl.innerHTML = albums.map(a => `<button data-type="album" data-id="${a.id}">${a.name}</button>`).join(' ');
  albumListEl.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentAlbum = albums.find(a => a.id === id);
      currentTrack = null;
      await populateHierarchyLists(section);
    });
  });
  const trackListEl = section.querySelector('#track-list');
  let tracks = [];
  if (currentAlbum) {
    const allTracks = await db.getAll('tracks');
    tracks = allTracks.filter(t => t.albumId === currentAlbum.id);
  }
  trackListEl.innerHTML = tracks.map(t => `<button data-type="track" data-id="${t.id}">${t.name}</button>`).join(' ');
  trackListEl.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      currentTrack = tracks.find(t => t.id === id);
      await populateHierarchyLists(section);
    });
  });
  const contBtn = section.querySelector('#continue-wizard');
  contBtn.disabled = !(currentWorld && currentProfile && currentAlbum && currentTrack);
}

// ----- Kompletta implementeringar av vyer -----
// Bank-vyn listar alla rader i banken och hanterar import/export via CSV
async function renderBank() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Bank: Rader & Rim</h2>
    <p>Här kan du söka i den lokala bankens rader, importera och exportera CSV.</p>
    <div class="form-group">
      <label for="theme-filter">Filtrera på tema</label>
      <select id="theme-filter"></select>
      <button id="filter-lines">Filtrera</button>
    </div>
    <div id="bank-table"></div>
    <div class="form-group">
      <label for="csv-file">Importera CSV med kolumner: id,base_text,type,themes,rewrite1,rewrite2,rewrite3,rewrite4</label>
      <input type="file" id="csv-file" accept=".csv" />
      <button id="import-csv">Importera</button>
    </div>
    <div class="form-group">
      <button id="export-csv">Exportera CSV (alla rader)</button>
    </div>
  `;
  viewContainer.appendChild(section);
  const themes = await db.getAll('themes');
  const select = section.querySelector('#theme-filter');
  select.innerHTML = '<option value="">– Alla –</option>' + themes.map(t => `<option value="${t.name}">${t.name}</option>`).join('');
  await renderBankTable(section, null);
  section.querySelector('#filter-lines').addEventListener('click', async () => {
    const val = select.value;
    await renderBankTable(section, val || null);
  });
  section.querySelector('#import-csv').addEventListener('click', async () => {
    const fileInput = section.querySelector('#csv-file');
    if (!fileInput.files.length) return;
    const file = fileInput.files[0];
    const text = await file.text();
    const rows = text.trim().split(/\n+/);
    for (const row of rows.slice(1)) {
      const [id, base_text, type, themesStr, r1, r2, r3, r4] = row.split(',');
      const themesArr = themesStr ? themesStr.split('|').map(s => s.trim()) : [];
      await db.add('lines', { id: id || crypto.randomUUID(), base_text, type, themes: themesArr, rewrites: [r1, r2, r3, r4], ratings: { impact: 3, novelty: 3, singability: 3, clarity: 3 }, suno_notes: {} });
    }
    alert('Import klar!');
    await renderBankTable(section, null);
  });
  section.querySelector('#export-csv').addEventListener('click', async () => {
    const lines = await db.getAll('lines');
    let csv = 'id,base_text,type,themes,rewrite1,rewrite2,rewrite3,rewrite4\n';
    for (const row of lines) {
      const themesJoined = row.themes ? row.themes.join('|') : '';
      csv += `${row.id},"${row.base_text.replace(/"/g,'""')}",${row.type},${themesJoined},"${row.rewrites[0]}","${row.rewrites[1]}","${row.rewrites[2]}","${row.rewrites[3]}"\n`;
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bank_export.csv';
    a.click();
    URL.revokeObjectURL(url);
  });
}

async function renderBankTable(section, themeFilter) {
  const container = section.querySelector('#bank-table');
  let lines;
  if (themeFilter) {
    lines = await db.queryLinesByTheme(themeFilter);
  } else {
    lines = await db.getAll('lines');
  }
  if (!lines.length) {
    container.innerHTML = '<p>Inga rader hittades.</p>';
    return;
  }
  let html = '<table><tr><th>ID</th><th>Text</th><th>Teman</th></tr>';
  for (const row of lines) {
    html += `<tr><td>${row.id}</td><td>${row.base_text}</td><td>${row.themes ? row.themes.join(', ') : ''}</td></tr>`;
  }
  html += '</table>';
  container.innerHTML = html;
}

// Wizard-vyn: fem val som genererar prompts
function renderWizard() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Wizard – 5 val</h2>
    <p>Varje steg i skapandet har fem alternativ. Du väljer ett för att fortsätta.</p>
    <div class="wizard-buttons">
      <button data-level="1">1. Snabb</button>
      <button data-level="2">2. Standard</button>
      <button data-level="3">3. Djup</button>
      <button data-level="4">4. Experiment</button>
      <button data-level="5">5. Felsök</button>
    </div>
    <div id="prompt-output">
      <p>Välj ett alternativ för att generera en prompt.</p>
    </div>
  `;
  viewContainer.appendChild(section);
  section.querySelectorAll('.wizard-buttons button').forEach(btn => {
    btn.addEventListener('click', async () => {
      const level = btn.dataset.level;
      const prompt = await generatePrompt(level);
      const output = section.querySelector('#prompt-output');
      output.innerHTML = `<textarea style="width:100%;height:180px;">${prompt}</textarea><br/><button id="copy-prompt">Kopiera prompt</button>`;
      output.querySelector('#copy-prompt').addEventListener('click', () => {
        const ta = output.querySelector('textarea');
        ta.select();
        document.execCommand('copy');
        alert('Prompt kopierad!');
      });
    });
  });
}

async function generatePrompt(level) {
  const levels = {
    '1': 'Snabb',
    '2': 'Standard',
    '3': 'Djup',
    '4': 'Experiment',
    '5': 'Felsök'
  };
  const levelName = levels[level] || 'Standard';
  const worldName = currentWorld ? currentWorld.name : 'okänd värld';
  const profileName = currentProfile ? currentProfile.name : 'okänd profil';
  const albumName = currentAlbum ? currentAlbum.name : 'okänt album';
  const trackName = currentTrack ? currentTrack.name : 'okänt spår';
  return `Du arbetar med värld "${worldName}", profil "${profileName}", album "${albumName}", spår "${trackName}".\n` +
    `Du har valt läge ${levelName}. Generera en låttextstruktur med lämpliga rim och metaforer från banken. Följ DBTS-reglerna för svensk melopoesi.\n` +
    `Steg efter detta: 1. Snabb 2. Standard 3. Djup 4. Experiment 5. Felsök`;
}

// Suno-export: generera paket med lyrics, stil, exclude och notes
function renderSuno() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Suno Export</h2>
    <p>Samla din låttext, stil och negativa prompt här och exportera till Suno PRO v5.</p>
    <div class="form-group">
      <label for="lyrics-area">Lyrics (sektioner i block med [VERSE], [HOOK], [BRIDGE])</label>
      <textarea id="lyrics-area" rows="8" placeholder="[VERSE]\nDin text här..."></textarea>
    </div>
    <div class="form-group">
      <label for="style-input">Stilbeskrivning (engelska)</label>
      <input id="style-input" placeholder="Swedish vals-trap, 6/8, 74-80 BPM" />
    </div>
    <div class="form-group">
      <label for="exclude-input">Exclude (negativ prompt)</label>
      <input id="exclude-input" placeholder="Exclude: autotune, cliché, english" />
    </div>
    <div class="form-group">
      <label for="notes-input">Metadata/Persona/Reuse hints</label>
      <input id="notes-input" placeholder="Persona: ...; Reuse Prompt: yes" />
    </div>
    <button id="generate-suno">Generera Suno-paket</button>
    <div id="suno-output"></div>
  `;
  viewContainer.appendChild(section);
  section.querySelector('#generate-suno').addEventListener('click', () => {
    const lyrics = section.querySelector('#lyrics-area').value.trim();
    const style = section.querySelector('#style-input').value.trim();
    const exclude = section.querySelector('#exclude-input').value.trim();
    const notes = section.querySelector('#notes-input').value.trim();
    const pkg = `Lyrics:\n${lyrics}\n\nStyle: ${style}\nExclude: ${exclude}\nNotes: ${notes}`;
    const out = section.querySelector('#suno-output');
    out.innerHTML = `<textarea style="width:100%;height:200px;">${pkg}</textarea><br/><button id="copy-suno">Kopiera</button>`;
    out.querySelector('#copy-suno').addEventListener('click', () => {
      const ta = out.querySelector('textarea');
      ta.select();
      document.execCommand('copy');
      alert('Suno-paket kopierat!');
    });
  });
}

// Vault: anteckningar och snapshotshistorik
function renderVault() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Vault / Logg</h2>
    <p>Här kan du skriva anteckningar för spåret och spara snapshot. Funktionaliteten är minimal i denna MVP.</p>
    <div class="form-group">
      <label for="note-area">Anteckningar</label>
      <textarea id="note-area" rows="6" placeholder="Skriv dina tankar om detta spår..."></textarea>
    </div>
    <button id="save-note">Spara anteckning</button>
    <div id="vault-list"></div>
  `;
  viewContainer.appendChild(section);
  loadVaultList(section);
  section.querySelector('#save-note').addEventListener('click', async () => {
    if (!currentTrack) { alert('Välj ett spår under Hem.'); return; }
    const note = section.querySelector('#note-area').value.trim();
    if (!note) return;
    await db.add('vault', { trackId: currentTrack.id, note, timestamp: Date.now() });
    section.querySelector('#note-area').value = '';
    loadVaultList(section);
  });
}

async function loadVaultList(section) {
  const list = section.querySelector('#vault-list');
  if (!currentTrack) {
    list.innerHTML = '<p>Inga anteckningar – välj spår under Hem.</p>';
    return;
  }
  const allNotes = await db.getAll('vault');
  const notes = allNotes.filter(n => n.trackId === currentTrack.id).sort((a,b) => b.timestamp - a.timestamp).slice(0,10);
  if (!notes.length) {
    list.innerHTML = '<p>Inga anteckningar sparade för detta spår.</p>';
    return;
  }
  let html = '<ul>';
  for (const n of notes) {
    const date = new Date(n.timestamp).toLocaleString();
    html += `<li><strong>${date}</strong>: ${n.note}</li>`;
  }
  html += '</ul>';
  list.innerHTML = html;
}

// Inställningar: export/import JSON och persistent storage
function renderSettings() {
  const section = document.createElement('section');
  section.innerHTML = `
    <h2>Inställningar & Backup</h2>
    <p>Spara och importera hela databasen som JSON. Notera att export/import skriver över nuvarande data.</p>
    <button id="export-json">Exportera JSON</button>
    <div class="form-group">
      <label for="json-file">Importera JSON backup</label>
      <input type="file" id="json-file" accept=".json" />
      <button id="import-json">Importera</button>
    </div>
    <p>När du kör appen på en säker domän (https) kan du aktivera persistent lagring för att minska risken att webbläsaren rensar datat. Denna funktion kräver ett säkert ursprung.</p>
    <button id="request-persist">Begär persistent lagring</button>
    <div id="storage-status"></div>
  `;
  viewContainer.appendChild(section);
  section.querySelector('#export-json').addEventListener('click', async () => {
    const stores = ['worlds','profiles','albums','tracks','lines','themes','vault'];
    const exportData = {};
    for (const store of stores) {
      exportData[store] = await db.getAll(store);
    }
    const blob = new Blob([JSON.stringify(exportData)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'lyrikos_backup.json';
    a.click();
    URL.revokeObjectURL(url);
  });
  section.querySelector('#import-json').addEventListener('click', async () => {
    const fileInput = section.querySelector('#json-file');
    if (!fileInput.files.length) return;
    const file = fileInput.files[0];
    const text = await file.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      alert('Filen är inte giltig JSON.'); return;
    }
    const dbConn = await db.init();
    const tx = dbConn.transaction(['worlds','profiles','albums','tracks','lines','themes','vault'], 'readwrite');
    for (const storeName of ['worlds','profiles','albums','tracks','lines','themes','vault']) {
      const store = tx.objectStore(storeName);
      await store.clear();
      if (Array.isArray(data[storeName])) {
        for (const entry of data[storeName]) {
          store.put(entry);
        }
      }
    }
    tx.oncomplete = () => {
      alert('Import klar!');
    };
  });
  section.querySelector('#request-persist').addEventListener('click', async () => {
    if (navigator.storage && navigator.storage.persist) {
      const granted = await navigator.storage.persist();
      section.querySelector('#storage-status').textContent = granted ? 'Persistent lagring aktiverad.' : 'Kunde inte aktivera persistent lagring.';
    } else {
      section.querySelector('#storage-status').textContent = 'Persistent storage stöds inte i denna webbläsare.';
    }
  });
}

// Starta applikationen när sidan laddats
document.addEventListener('DOMContentLoaded', () => {
  init();
});