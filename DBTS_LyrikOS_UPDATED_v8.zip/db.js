// db.js – simpel IndexedDB wrapper för LyrikOS

export class DB {
  constructor(name = 'lyrikos', version = 1) {
    this.name = name;
    this.version = version;
    this.db = null;
  }

  async init() {
    if (this.db) return this.db;
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.name, this.version);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        // Create object stores
        const worldStore = db.createObjectStore('worlds', { keyPath: 'id', autoIncrement: true });
        worldStore.createIndex('name', 'name', { unique: false });
        const profileStore = db.createObjectStore('profiles', { keyPath: 'id', autoIncrement: true });
        profileStore.createIndex('worldId', 'worldId', { unique: false });
        const albumStore = db.createObjectStore('albums', { keyPath: 'id', autoIncrement: true });
        albumStore.createIndex('profileId', 'profileId', { unique: false });
        const trackStore = db.createObjectStore('tracks', { keyPath: 'id', autoIncrement: true });
        trackStore.createIndex('albumId', 'albumId', { unique: false });
        // Lines for rim/metaforer etc
        const lineStore = db.createObjectStore('lines', { keyPath: 'id' });
        lineStore.createIndex('themes', 'themes', { multiEntry: true });
        // Themes store
        const themeStore = db.createObjectStore('themes', { keyPath: 'id', autoIncrement: true });
        themeStore.createIndex('name', 'name', { unique: true });
        // Vault store for snapshots and notes
        const vaultStore = db.createObjectStore('vault', { keyPath: 'id', autoIncrement: true });
        vaultStore.createIndex('trackId', 'trackId', { unique: false });
      };
      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };
      request.onerror = (event) => {
        console.error('DB error', event.target.error);
        reject(event.target.error);
      };
    });
  }

  async withStore(storeName, mode, callback) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      let req;
      callback(store, tx);
      tx.oncomplete = () => resolve();
      tx.onerror = (event) => reject(event.target.error);
    });
  }

  async add(storeName, value) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.add(value);
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }

  async getAll(storeName) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }

  async count(storeName) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.count();
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }

  async queryLinesByTheme(theme) {
    const db = await this.init();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('lines', 'readonly');
      const store = tx.objectStore('lines');
      const index = store.index('themes');
      const request = index.getAll(IDBKeyRange.only(theme));
      request.onsuccess = () => resolve(request.result);
      request.onerror = (event) => reject(event.target.error);
    });
  }
}

export default DB;